import { create } from "zustand";

/**
 * Admin-session-only view of persisted public submissions that have no slot in the tenant document:
 * guest reviews awaiting moderation and contact messages. Populated exclusively by lib/customerData.ts
 * after the owner's tenant is verified; cleared on tenant stop / account switch. Never used by the
 * public storefront.
 */
export interface PendingReview {
  id: string;
  name: string;
  text: string;
  rating: number;
  date: string;
}

export interface ContactMessage {
  id: string;
  name: string;
  email: string;
  subject: string;
  message: string;
  createdAt: string;
}

interface CustomerInboxState {
  pendingReviews: PendingReview[];
  contactMessages: ContactMessage[];
}

export const useCustomerInboxStore = create<CustomerInboxState>()(() => ({
  pendingReviews: [],
  contactMessages: [],
}));

export function clearCustomerInbox() {
  useCustomerInboxStore.setState({ pendingReviews: [], contactMessages: [] });
}
