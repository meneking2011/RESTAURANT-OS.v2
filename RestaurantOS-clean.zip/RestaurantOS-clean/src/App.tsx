import { Suspense, lazy, useEffect, useState, type ReactNode } from "react";
import { Switch, Route, Router as WouterRouter, useLocation } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/components/ThemeProvider";
import NotFound from "@/pages/not-found";
import PlatformHomepage from "@/pages/PlatformHomepage";
import { LoadingSpinner } from "@/components/ui/LoadingSpinner";
import { Wrench } from "lucide-react";
import { AuthProvider, useAuth } from "@/lib/auth";
import { auth } from "@/lib/firebase";
import { resolvePublishedStorefront } from "@/lib/publicStorefront";
import { PlatformStorefrontProvider, PublicStorefrontProvider, usePlatformStorefront, usePublicStorefront, usePublicStorefrontOptional } from "@/lib/publicStorefrontContext";
import { useRestaurantStore } from "@/store/restaurantStore";

const HomePage = lazy(() => import("@/pages/HomePage"));
const CustomPageView = lazy(() => import("@/pages/CustomPageView"));
const MenuPage = lazy(() => import("@/pages/MenuPage"));
const AboutPage = lazy(() => import("@/pages/AboutPage"));
const ServicesPage = lazy(() => import("@/pages/ServicesPage"));
const ReservationsPage = lazy(() => import("@/pages/ReservationsPage"));
const LocateUsPage = lazy(() => import("@/pages/LocateUsPage"));
const ContactPage = lazy(() => import("@/pages/ContactPage"));
const CheckoutPage = lazy(() => import("@/pages/CheckoutPage"));

const AdminDashboard = lazy(() => import("@/admin/pages/AdminDashboard"));
const AdminMenu = lazy(() => import("@/admin/pages/AdminMenu"));
const AdminServices = lazy(() => import("@/admin/pages/AdminServices"));
const AdminTestimonials = lazy(() => import("@/admin/pages/AdminTestimonials"));
const AdminReservations = lazy(() => import("@/admin/pages/AdminReservations"));
const AdminOrders = lazy(() => import("@/admin/pages/AdminOrders"));
const AdminGallery = lazy(() => import("@/admin/pages/AdminGallery"));
const AdminBusinessDetails = lazy(() => import("@/admin/pages/AdminBusinessDetails"));
const AdminSettings = lazy(() => import("@/admin/pages/AdminSettings"));
const AdminDesignTokens = lazy(() => import("@/admin/pages/AdminDesignTokens"));
const AdminMediaLibrary = lazy(() => import("@/admin/pages/AdminMediaLibrary"));
const AdminPages = lazy(() => import("@/admin/pages/AdminPages"));
const AdminCustomPageEditor = lazy(() => import("@/admin/pages/AdminCustomPageEditor"));
const AdminNavigation = lazy(() => import("@/admin/pages/AdminNavigation"));
const AdminWebsite = lazy(() => import("@/admin/pages/AdminWebsite"));
const AdminAnalytics = lazy(() => import("@/admin/pages/AdminAnalytics"));
const AdminLogin = lazy(() => import("@/admin/pages/AdminLogin"));

const queryClient = new QueryClient();

const PLATFORM_HOSTNAME = "restaurant-os-88262.web.app";

function ApplyPageMetadata({
  name,
  description,
  favicon,
  logo,
}: {
  name: string;
  description: string;
  favicon?: string;
  logo?: string;
}) {
  useEffect(() => {
    const title = name.trim() || "RestaurantOS";
    document.title = title;

    const descriptionMeta = document.querySelector('meta[name="description"]');
    descriptionMeta?.setAttribute("content", description);

    let icon = document.querySelector<HTMLLinkElement>('link[rel="icon"]');
    if (!icon) {
      icon = document.createElement("link");
      icon.rel = "icon";
      document.head.appendChild(icon);
    }
    icon.type = favicon || logo ? "image/png" : "image/svg+xml";
    icon.href = favicon || logo || "/favicon.svg";
  }, [name, description, favicon, logo]);

  return null;
}

function AdminPageMetadata() {
  const config = useRestaurantStore((s) => s.config);
  const name = config.name.trim() || "RestaurantOS";
  const description = `${name}${config.description.trim() ? ` — ${config.description.trim()}` : ""}`;
  return <ApplyPageMetadata name={name} description={description} favicon={config.favicon} logo={config.logo} />;
}

function PublicPageMetadata() {
  const config = usePublicStorefront((s) => s.config);
  const name = config.name.trim() || "RestaurantOS";
  const description = `${name}${config.description.trim() ? ` — ${config.description.trim()}` : ""}`;
  return <ApplyPageMetadata name={name} description={description} favicon={config.favicon} logo={config.logo} />;
}

function DynamicPageMetadata() {
  const publicStorefront = usePublicStorefrontOptional();
  const [location] = useLocation();
  if (publicStorefront) return <PublicPageMetadata />;
  if (location.startsWith("/admin")) return <AdminPageMetadata />;
  return (
    <ApplyPageMetadata
      name="RestaurantOS"
      description="The operating system for modern restaurants."
    />
  );
}

function FallbackLoader() {
  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-background">
      <LoadingSpinner className="w-10 h-10 text-primary" />
    </div>
  );
}

function MaintenancePage() {
  const config = usePublicStorefront((s) => s.config);
  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center text-center px-6">
      <div className="w-20 h-20 rounded-full bg-primary/10 border border-primary/30 flex items-center justify-center mb-8">
        <Wrench className="w-8 h-8 text-primary" />
      </div>
      <h1 className="font-serif text-4xl md:text-6xl uppercase tracking-widest mb-4 text-foreground">
        {config.name}
      </h1>
      <p className="text-muted-foreground text-lg mb-2 tracking-wide uppercase">
        Under Maintenance
      </p>
      <p className="text-muted-foreground/60 text-sm max-w-md leading-relaxed">
        We are making improvements to serve you better. Please check back shortly.
      </p>
      <p className="text-xs text-muted-foreground/40 mt-10">
        Restaurant staff:{" "}
        <a href="/admin" className="text-primary hover:underline">
          Admin Panel
        </a>
      </p>
    </div>
  );
}

/** Gate for every /admin/* route except /admin/login. Redirects unauthenticated visitors to sign in. */
function RequireAuth({ component: Component }: { component: React.ComponentType }) {
  const { user, restaurantId, loading, authInitialized, error } = useAuth();
  const [, navigate] = useLocation();

  useEffect(() => {
    if (authInitialized && !loading && !user) {
      if (import.meta.env.DEV) console.log("[v0] admin guard redirect", { currentUser: Boolean(auth.currentUser) });
      navigate("/admin/login");
    }
  }, [authInitialized, loading, user, navigate]);

  if (!authInitialized || loading) return <FallbackLoader />;
  if (!user) return <FallbackLoader />;
  if (!restaurantId) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6 text-center">
        <div className="max-w-md space-y-3">
          <h1 className="text-xl font-semibold">Restaurant initialization failed</h1>
          <p className="text-sm text-muted-foreground">{error ?? "Your account is authenticated, but its restaurant could not be loaded."}</p>
          <p className="text-xs text-muted-foreground">Sign out and try again, or contact an administrator if this persists.</p>
        </div>
      </div>
    );
  }
  return <Component />;
}

function AuthScope({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return location.startsWith("/admin") ? <AuthProvider>{children}</AuthProvider> : <>{children}</>;
}

function PublicShell({ children }: { children: ReactNode }) {
  return (
    <ThemeProvider>
      <DynamicPageMetadata />
      {children}
    </ThemeProvider>
  );
}

function PublicTenantGate({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const [status, setStatus] = useState<"loading" | "ready" | "missing">("loading");
  const [storefront, setStorefront] = useState<Awaited<ReturnType<typeof resolvePublishedStorefront>>>(null);
  const platform = usePlatformStorefront();
  const isAdmin = location.startsWith("/admin");
  const isPlatformHome = window.location.hostname === PLATFORM_HOSTNAME && location === "/";

  useEffect(() => {
    if (isAdmin || isPlatformHome) return;
    let cancelled = false;
    setStatus("loading");
    void resolvePublishedStorefront(window.location.hostname).then((resolved) => {
      if (cancelled) return;
      // Public visitors only receive published data. Never hydrate, reset, or
      // write the private admin Zustand tenant store from this path.
      setStorefront(resolved);
      setStatus(resolved ? "ready" : "missing");
    }).catch((error) => {
      if (!cancelled) {
        console.error("[v0] public storefront resolution failed", error);
        setStorefront(null);
        setStatus("missing");
      }
    });
    return () => { cancelled = true; };
  }, [isAdmin, isPlatformHome]);

  if (isAdmin) return <PublicShell>{children}</PublicShell>;
  if (isPlatformHome) {
    if (platform.loading) return <FallbackLoader />;
    if (platform.storefront) {
      return (
        <PublicStorefrontProvider storefront={platform.storefront}>
          <PublicShell>{platform.storefront.quickControls.maintenanceMode ? <MaintenancePage /> : children}</PublicShell>
        </PublicStorefrontProvider>
      );
    }
    return <PublicShell><PlatformHomepage error={platform.error} /></PublicShell>;
  }
  if (status === "loading") return <FallbackLoader />;
  if (status === "ready" && storefront) {
    return (
      <PublicStorefrontProvider storefront={storefront}>
        <PublicShell>
          {storefront.quickControls.maintenanceMode ? <MaintenancePage /> : children}
        </PublicShell>
      </PublicStorefrontProvider>
    );
  }
  return <PublicShell><NotFound /></PublicShell>;
}

function Router() {
  return (
    <Suspense fallback={<FallbackLoader />}>
      <Switch>
        <Route path="/" component={HomePage} />
        <Route path="/menu" component={MenuPage} />
        <Route path="/about" component={AboutPage} />
        <Route path="/services" component={ServicesPage} />
        <Route path="/reservations" component={ReservationsPage} />
        <Route path="/locate-us" component={LocateUsPage} />
        <Route path="/contact" component={ContactPage} />
        <Route path="/checkout" component={CheckoutPage} />

        <Route path="/admin/login" component={AdminLogin} />

        <Route path="/admin" component={() => <RequireAuth component={AdminDashboard} />} />
        <Route path="/admin/website" component={() => <RequireAuth component={AdminWebsite} />} />
        <Route path="/admin/business" component={() => <RequireAuth component={AdminBusinessDetails} />} />
        <Route path="/admin/menu" component={() => <RequireAuth component={AdminMenu} />} />
        <Route path="/admin/reservations" component={() => <RequireAuth component={AdminReservations} />} />
        <Route path="/admin/orders" component={() => <RequireAuth component={AdminOrders} />} />
        <Route path="/admin/gallery" component={() => <RequireAuth component={AdminGallery} />} />
        <Route path="/admin/media" component={() => <RequireAuth component={AdminMediaLibrary} />} />
        <Route path="/admin/design-tokens" component={() => <RequireAuth component={AdminDesignTokens} />} />
        <Route path="/admin/navigation" component={() => <RequireAuth component={AdminNavigation} />} />
        <Route path="/admin/pages" component={() => <RequireAuth component={AdminPages} />} />
        <Route path="/admin/pages/:pageId" component={() => <RequireAuth component={AdminCustomPageEditor} />} />
        <Route path="/admin/services" component={() => <RequireAuth component={AdminServices} />} />
        <Route path="/admin/testimonials" component={() => <RequireAuth component={AdminTestimonials} />} />
        <Route path="/admin/analytics" component={() => <RequireAuth component={AdminAnalytics} />} />
        <Route path="/admin/settings" component={() => <RequireAuth component={AdminSettings} />} />

        {/* Dynamic catch-all: checks custom pages before showing 404 */}
        <Route path="/:slug">
          {(params) => <CustomPageView slug={(params as { slug?: string } | undefined)?.slug ?? ""} />}
        </Route>

        <Route component={NotFound} />
      </Switch>
    </Suspense>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <AuthScope>
            <PlatformStorefrontProvider>
              <PublicTenantGate>
                <Router />
              </PublicTenantGate>
            </PlatformStorefrontProvider>
          </AuthScope>
          <Toaster />
        </WouterRouter>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
