/**
 * C3 — ADMIN-side access to persisted customer records.
 *
 * Started/stopped only by the authenticated admin tenant lifecycle (tenantSync.startTenantSync /
 * stopTenantSync, which run under /admin after ownership is verified). Reads and writes ONLY
 * `restaurants/{restaurantId}/…` for the verified owner's restaurantId; Firestore rules independently
 * restrict these collections to that owner. The public storefront never imports this module.
 *
 * Orders / reservations are mirrored into the existing admin store so the existing admin UI keeps
 * working, but they are NOT part of the tenant document write (see tenantSync) — the subcollections
 * are the source of truth.
 */
import {
  collection,
  deleteDoc,
  deleteField,
  doc,
  getDocs,
  onSnapshot,
  updateDoc,
  writeBatch,
  type DocumentData,
  type Unsubscribe,
} from "firebase/firestore";
import { deleteObject, getDownloadURL, ref } from "firebase/storage";
import { db, storage } from "./firebase";
import {
  setCustomerDataPersistence,
  useRestaurantStore,
  type Reservation,
} from "@/store/restaurantStore";
import { clearCustomerInbox, useCustomerInboxStore, type ContactMessage, type PendingReview } from "@/store/customerInboxStore";
import type { Order, OrderStatus, PaymentStatus } from "@/types/restaurant";

/** Tenant-document keys that are no longer written by tenant sync — they live in subcollections. */
export const CUSTOMER_COLLECTION_KEYS = ["orders", "reservations", "visitLog"] as const;

type Active = () => boolean;

let unsubscribers: Unsubscribe[] = [];
let activeRestaurantId: string | null = null;

const str = (v: unknown, fallback = ""): string => (typeof v === "string" ? v : fallback);
const num = (v: unknown, fallback = 0): number => (typeof v === "number" && Number.isFinite(v) ? v : fallback);

function toOrder(id: string, d: DocumentData): Order {
  return {
    id,
    customerName: str(d.customerName),
    email: str(d.email),
    phone: str(d.phone),
    deliveryAddress: str(d.deliveryAddress),
    items: Array.isArray(d.items) ? d.items : [],
    paymentMethod: "bankTransfer",
    selectedBankAccountId: typeof d.selectedBankAccountId === "string" ? d.selectedBankAccountId : undefined,
    paymentStatus: str(d.paymentStatus, "pending_receipt") as PaymentStatus,
    paymentVerifiedAt: typeof d.paymentVerifiedAt === "string" ? d.paymentVerifiedAt : undefined,
    paymentRejectedAt: typeof d.paymentRejectedAt === "string" ? d.paymentRejectedAt : undefined,
    paymentRejectionReason: typeof d.paymentRejectionReason === "string" ? d.paymentRejectionReason : undefined,
    status: str(d.status, "new") as OrderStatus,
    subtotal: num(d.subtotal),
    deliveryFee: num(d.deliveryFee),
    tax: num(d.tax),
    totalAmount: num(d.totalAmount),
    specialNotes: typeof d.specialNotes === "string" ? d.specialNotes : undefined,
    orderedAt: str(d.orderedAt, new Date(0).toISOString()),
  };
}

function toReservation(id: string, d: DocumentData): Reservation {
  return {
    id,
    name: str(d.name),
    email: str(d.email),
    phone: str(d.phone),
    date: str(d.date),
    time: str(d.time),
    guests: num(d.guests, 1),
    table: typeof d.table === "string" ? d.table : undefined,
    occasion: typeof d.occasion === "string" ? d.occasion : undefined,
    notes: typeof d.notes === "string" ? d.notes : undefined,
    status: (str(d.status, "pending") as Reservation["status"]),
    createdAt: str(d.createdAt, new Date(0).toISOString()),
    paymentPaid: typeof d.paymentPaid === "boolean" ? d.paymentPaid : undefined,
    paymentAmount: typeof d.paymentAmount === "number" ? d.paymentAmount : undefined,
  };
}

const byNewest = <T extends { orderedAt?: string; createdAt?: string }>(a: T, b: T) =>
  String(b.orderedAt ?? b.createdAt).localeCompare(String(a.orderedAt ?? a.createdAt));

/** Firestore rejects `undefined`; an explicit undefined in a patch means "remove this field". */
function toUpdate(patch: Record<string, unknown>): Record<string, unknown> {
  const out: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(patch)) out[k] = v === undefined ? deleteField() : v;
  return out;
}

async function deleteCollection(restaurantId: string, name: string): Promise<DocumentData[]> {
  const snap = await getDocs(collection(db, "restaurants", restaurantId, name));
  const removed: DocumentData[] = [];
  for (let i = 0; i < snap.docs.length; i += 400) {
    const batch = writeBatch(db);
    snap.docs.slice(i, i + 400).forEach((d) => { batch.delete(d.ref); removed.push(d.data()); });
    await batch.commit();
  }
  return removed;
}

export function stopCustomerDataSync() {
  unsubscribers.forEach((u) => u());
  unsubscribers = [];
  const hadTenant = activeRestaurantId !== null;
  activeRestaurantId = null;
  setCustomerDataPersistence(null);
  if (hadTenant) {
    // Never leave one owner's customer records in memory for the next account.
    useRestaurantStore.setState({ orders: [], reservations: [] });
    clearCustomerInbox();
  }
}

export function startCustomerDataSync(restaurantId: string, ownerUid: string, isActive: Active) {
  stopCustomerDataSync();
  if (!restaurantId || !ownerUid) return;
  activeRestaurantId = restaurantId;
  const col = (name: string) => collection(db, "restaurants", restaurantId, name);
  const guard = () => isActive() && activeRestaurantId === restaurantId;
  const log = (message: string, detail: string) => useRestaurantStore.getState().addActivityLog({ message, detail });

  let orderDocs = new Map<string, DocumentData>();
  let receiptDocs = new Map<string, DocumentData>();
  const receiptUrls = new Map<string, string>();
  const requestedUrls = new Set<string>();

  const publishOrders = () => {
    if (!guard()) return;
    const orders = [...orderDocs.entries()].map(([id, d]) => {
      const order = toOrder(id, d);
      const receipt = receiptDocs.get(id);
      if (!receipt) return order;
      return {
        ...order,
        receiptFileName: str(receipt.receiptFileName),
        receiptUploadedAt: str(receipt.uploadedAt),
        selectedBankAccountId: str(receipt.bankAccountId, order.selectedBankAccountId ?? ""),
        receiptUrl: receiptUrls.get(id),
        // The public can only attach a receipt document; the owner-controlled order document moves
        // on from pending_receipt only when the owner verifies/rejects.
        paymentStatus: (order.paymentStatus === "pending_receipt" ? "pending_verification" : order.paymentStatus) as PaymentStatus,
      };
    }).sort(byNewest);
    useRestaurantStore.setState({ orders });
  };

  const resolveReceiptUrl = (orderId: string, path: unknown) => {
    const expected = `restaurants/${restaurantId}/receipts/${orderId}/`;
    if (typeof path !== "string" || !path.startsWith(expected) || requestedUrls.has(orderId)) return;
    requestedUrls.add(orderId);
    getDownloadURL(ref(storage, path))
      .then((url) => { receiptUrls.set(orderId, url); publishOrders(); })
      .catch((err) => { requestedUrls.delete(orderId); console.error("[customerData] receipt URL failed", err); });
  };

  const onErr = (label: string) => (err: unknown) => console.error(`[customerData] ${label} listener error:`, err);

  let ordersReady = false;
  unsubscribers.push(onSnapshot(col("orders"), (snap) => {
    if (!guard()) return;
    orderDocs = new Map(snap.docs.map((d) => [d.id, d.data()]));
    if (ordersReady) {
      snap.docChanges().filter((c) => c.type === "added" && !c.doc.metadata.hasPendingWrites).forEach((c) => {
        const d = c.doc.data();
        log("New Order", `Order from ${str(d.customerName, "a customer")} — ${Array.isArray(d.items) ? d.items.length : 0} item(s)`);
      });
    }
    ordersReady = true;
    publishOrders();
  }, onErr("orders")));

  let receiptsReady = false;
  unsubscribers.push(onSnapshot(col("orderReceipts"), (snap) => {
    if (!guard()) return;
    receiptDocs = new Map(snap.docs.map((d) => [d.id, d.data()]));
    snap.docs.forEach((d) => resolveReceiptUrl(d.id, d.data().receiptPath));
    if (receiptsReady) {
      snap.docChanges().filter((c) => c.type === "added").forEach((c) => {
        log("Receipt Uploaded", `Customer uploaded payment receipt for Order #${c.doc.id.replace("ord-", "").slice(0, 8)}`);
      });
    }
    receiptsReady = true;
    publishOrders();
  }, onErr("orderReceipts")));

  let reservationsReady = false;
  unsubscribers.push(onSnapshot(col("reservations"), (snap) => {
    if (!guard()) return;
    const reservations = snap.docs.map((d) => toReservation(d.id, d.data())).sort(byNewest);
    if (reservationsReady) {
      snap.docChanges().filter((c) => c.type === "added").forEach((c) => {
        const d = c.doc.data();
        log("New Reservation", `${str(d.name, "A guest")} booked a table for ${num(d.guests, 1)}`);
      });
    }
    reservationsReady = true;
    useRestaurantStore.setState({ reservations });
  }, onErr("reservations")));

  let messagesReady = false;
  unsubscribers.push(onSnapshot(col("contactMessages"), (snap) => {
    if (!guard()) return;
    const contactMessages: ContactMessage[] = snap.docs.map((d) => {
      const m = d.data();
      return { id: d.id, name: str(m.name), email: str(m.email), subject: str(m.subject), message: str(m.message), createdAt: str(m.createdAt) };
    }).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    if (messagesReady) {
      snap.docChanges().filter((c) => c.type === "added").forEach((c) => {
        log("New Message", `${str(c.doc.data().name, "A visitor")} sent a contact message`);
      });
    }
    messagesReady = true;
    useCustomerInboxStore.setState({ contactMessages });
  }, onErr("contactMessages")));

  let reviewsReady = false;
  unsubscribers.push(onSnapshot(col("reviewSubmissions"), (snap) => {
    if (!guard()) return;
    const pendingReviews: PendingReview[] = snap.docs
      .filter((d) => d.data().status === "pending")
      .map((d) => {
        const r = d.data();
        return { id: d.id, name: str(r.name), text: str(r.text), rating: num(r.rating, 5), date: str(r.date) };
      })
      .sort((a, b) => b.date.localeCompare(a.date));
    if (reviewsReady) {
      snap.docChanges().filter((c) => c.type === "added").forEach((c) => {
        log("New Review Submitted", `${str(c.doc.data().name, "A guest")} submitted a review for approval`);
      });
    }
    reviewsReady = true;
    useCustomerInboxStore.setState({ pendingReviews });
  }, onErr("reviewSubmissions")));

  // Write-through for the existing admin actions (status changes, verification, edits, deletes).
  const ORDER_PATCH_KEYS = new Set(["status", "paymentStatus", "paymentVerifiedAt", "paymentRejectedAt", "paymentRejectionReason"]);
  const RESERVATION_PATCH_KEYS = new Set(["name", "email", "phone", "date", "time", "guests", "table", "occasion", "notes", "status", "paymentPaid", "paymentAmount"]);
  const pick = (patch: Record<string, unknown>, allowed: Set<string>) =>
    Object.fromEntries(Object.entries(patch).filter(([k]) => allowed.has(k)));
  const fail = (label: string) => (err: unknown) => console.error(`[customerData] ${label} failed:`, err);

  setCustomerDataPersistence({
    updateOrder: (id, patch) => {
      if (!guard()) return;
      void updateDoc(doc(db, "restaurants", restaurantId, "orders", id), toUpdate(pick(patch, ORDER_PATCH_KEYS))).catch(fail("order update"));
    },
    updateReservation: (id, patch) => {
      if (!guard()) return;
      void updateDoc(doc(db, "restaurants", restaurantId, "reservations", id), toUpdate(pick(patch, RESERVATION_PATCH_KEYS))).catch(fail("reservation update"));
    },
    deleteReservation: (id) => {
      if (!guard()) return;
      void deleteDoc(doc(db, "restaurants", restaurantId, "reservations", id)).catch(fail("reservation delete"));
    },
    deleteAllReservations: () => {
      if (!guard()) return;
      void deleteCollection(restaurantId, "reservations").catch(fail("reservations reset"));
    },
    deleteAllOrders: () => {
      if (!guard()) return;
      void (async () => {
        const receipts = await deleteCollection(restaurantId, "orderReceipts");
        await deleteCollection(restaurantId, "orders");
        // Best-effort cleanup of uploaded receipt files (owner-only in storage rules).
        await Promise.allSettled(receipts.map((r) => {
          const path = r.receiptPath;
          return typeof path === "string" && path.startsWith(`restaurants/${restaurantId}/receipts/`)
            ? deleteObject(ref(storage, path))
            : Promise.resolve();
        }));
      })().catch(fail("orders reset"));
    },
  });
}

// ── Review moderation (used by AdminTestimonials) ─────────────────────────────

/** Publishes a pending guest review into the owner's testimonials and marks the submission handled. */
export async function approveReviewSubmission(review: PendingReview): Promise<void> {
  const restaurantId = activeRestaurantId;
  if (!restaurantId) throw new Error("No authenticated restaurant is active.");
  useRestaurantStore.getState().addTestimonial({ name: review.name, text: review.text, rating: review.rating, date: review.date });
  await updateDoc(doc(db, "restaurants", restaurantId, "reviewSubmissions", review.id), { status: "approved" });
}

export async function dismissReviewSubmission(id: string): Promise<void> {
  const restaurantId = activeRestaurantId;
  if (!restaurantId) throw new Error("No authenticated restaurant is active.");
  await deleteDoc(doc(db, "restaurants", restaurantId, "reviewSubmissions", id));
}
