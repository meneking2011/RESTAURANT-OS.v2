import type {
  BankAccount,
  CustomPage,
  DesignTokenPage,
  GalleryImage,
  MenuItem,
  RestaurantConfig,
  SectionKey,
  SectionMediaConfig,
  Service,
  SiteTheme,
  Testimonial,
} from "@/types/restaurant";
import type { DeliverySettings, NavLink, ReservationSettings } from "@/store/restaurantStore";

const RESERVED_ROUTES = new Set(["/", "/menu", "/about", "/services", "/reservations", "/locate-us", "/contact", "/checkout", "/admin"]);

export function normalizeCustomSlug(value: string): string {
  const segment = value.trim().toLowerCase().replace(/^\/+|\/+$/g, "").replace(/[^a-z0-9-\s]/g, "").replace(/\s+/g, "-").replace(/-+/g, "-").replace(/^-+|-+$/g, "");
  return segment ? `/${segment}` : "";
}

export function isReservedCustomSlug(value: string): boolean {
  const slug = normalizeCustomSlug(value);
  return !slug || RESERVED_ROUTES.has(slug) || slug === "/admin" || slug.startsWith("/admin/");
}

export function normalizeDomain(value: string): string {
  return value.trim().toLowerCase().replace(/^https?:\/\//, "").split("/")[0].split(":")[0].replace(/^www\./, "").replace(/\.$/, "");
}

const emptySection = (overlayOpacity = 0): SectionMediaConfig => ({
  images: [],
  backgroundImage: "",
  overlayColor: "#000000",
  overlayOpacity,
  backgroundColor: "",
  useBackgroundColor: false,
});

export const DEFAULT_PUBLIC_SECTION_MEDIA: Record<SectionKey, SectionMediaConfig> = {
  hero: emptySection(40),
  featuredDishes: emptySection(),
  about: emptySection(),
  services: emptySection(),
  gallery: emptySection(),
  cta: emptySection(40),
  footer: emptySection(),
};

export const DEFAULT_PUBLIC_QUICK_CONTROLS = {
  restaurantOpen: true,
  acceptReservations: true,
  onlineOrders: false,
  whatsapp: true,
  maintenanceMode: false,
};

export const DEFAULT_PUBLIC_DELIVERY_SETTINGS: DeliverySettings = {
  fee: 15,
  taxRate: 0.08,
  minOrder: 25,
  estimatedTime: "30-45",
  radiusKm: 10,
};

export const DEFAULT_PUBLIC_RESERVATION_SETTINGS: ReservationSettings = {
  maxPartySize: 10,
  maxTotalSeats: 50,
  slotDurationMins: 90,
  advanceNoticeHours: 24,
  maxAdvanceDays: 60,
  confirmationMessage:
    "Your reservation request has been received. Our team will contact you to confirm.",
  requirePayment: false,
  paymentAmount: 25,
  allowMultiple: false,
  multipleLimit: 1,
};

export type PublishedStorefront = {
  restaurantId: string;
  /**
   * The normalized hostname that `domains/{hostname}` resolved to this tenant. Public submissions
   * carry it so Firestore rules can confirm the (domain → restaurantId) pairing server-side.
   * Set only by resolvePublishedStorefront(); never user-supplied.
   */
  resolvedDomain?: string;
  config: RestaurantConfig;
  siteTheme: SiteTheme;
  menuItems: MenuItem[];
  services: Service[];
  testimonials: Testimonial[];
  galleryImages: GalleryImage[];
  navLinks: NavLink[];
  customPages: CustomPage[];
  quickControls: {
    restaurantOpen: boolean;
    acceptReservations: boolean;
    onlineOrders: boolean;
    whatsapp: boolean;
    maintenanceMode: boolean;
  };
  sectionMedia: Record<SectionKey, SectionMediaConfig>;
  themeOverrides: Partial<Record<DesignTokenPage, Partial<SiteTheme>>>;
  reservationSettings: ReservationSettings;
  deliverySettings: DeliverySettings;
  bankAccounts: BankAccount[];
};

function asArray<T>(value: unknown): T[] {
  return Array.isArray(value) ? (value as T[]) : [];
}

function asRecord<T extends object>(value: unknown, fallback: T): T {
  return value && typeof value === "object" && !Array.isArray(value) ? { ...fallback, ...(value as T) } : fallback;
}

/** Shape published Firestore data into a complete public storefront. Never touches the admin Zustand store. */
export function normalizePublishedStorefront(
  restaurantId: string,
  data: Record<string, unknown>,
): PublishedStorefront | null {
  const config = data.config;
  const siteTheme = data.siteTheme;
  if (!config || typeof config !== "object" || !siteTheme || typeof siteTheme !== "object") return null;
  const quick = asRecord(data.quickControls, DEFAULT_PUBLIC_QUICK_CONTROLS);
  const incomingMedia = (data.sectionMedia && typeof data.sectionMedia === "object" ? data.sectionMedia : {}) as Partial<Record<SectionKey, SectionMediaConfig>>;
  return {
    restaurantId,
    config: config as RestaurantConfig,
    siteTheme: siteTheme as SiteTheme,
    menuItems: asArray<MenuItem>(data.menuItems),
    services: asArray<Service>(data.services),
    testimonials: asArray<Testimonial>(data.testimonials),
    galleryImages: asArray<GalleryImage>(data.galleryImages),
    navLinks: asArray<NavLink>(data.navLinks),
    customPages: asArray<CustomPage>(data.customPages),
    quickControls: {
      restaurantOpen: Boolean(quick.restaurantOpen),
      acceptReservations: Boolean(quick.acceptReservations),
      onlineOrders: Boolean(quick.onlineOrders),
      whatsapp: Boolean(quick.whatsapp),
      maintenanceMode: Boolean(quick.maintenanceMode),
    },
    sectionMedia: {
      hero: asRecord(incomingMedia.hero, DEFAULT_PUBLIC_SECTION_MEDIA.hero),
      featuredDishes: asRecord(incomingMedia.featuredDishes, DEFAULT_PUBLIC_SECTION_MEDIA.featuredDishes),
      about: asRecord(incomingMedia.about, DEFAULT_PUBLIC_SECTION_MEDIA.about),
      services: asRecord(incomingMedia.services, DEFAULT_PUBLIC_SECTION_MEDIA.services),
      gallery: asRecord(incomingMedia.gallery, DEFAULT_PUBLIC_SECTION_MEDIA.gallery),
      cta: asRecord(incomingMedia.cta, DEFAULT_PUBLIC_SECTION_MEDIA.cta),
      footer: asRecord(incomingMedia.footer, DEFAULT_PUBLIC_SECTION_MEDIA.footer),
    },
    themeOverrides: asRecord(data.themeOverrides, {} as PublishedStorefront["themeOverrides"]),
    reservationSettings: asRecord(data.reservationSettings, DEFAULT_PUBLIC_RESERVATION_SETTINGS),
    deliverySettings: asRecord(data.deliverySettings, DEFAULT_PUBLIC_DELIVERY_SETTINGS),
    bankAccounts: asArray<BankAccount>(data.bankAccounts),
  };
}

async function firestore() {
  const [{ doc, getDoc }, { db }] = await Promise.all([
    import("firebase/firestore"),
    import("./firebase"),
  ]);
  return { doc, getDoc, db };
}

export async function resolveDomainTenant(hostname: string): Promise<string | null> {
  const domain = normalizeDomain(hostname);
  if (!domain) return null;
  const { doc, getDoc, db } = await firestore();
  const snap = await getDoc(doc(db, "domains", domain));
  if (!snap.exists()) return null;
  const restaurantId = snap.data().restaurantId;
  return typeof restaurantId === "string" && /^rest_[A-Za-z0-9_-]+$/.test(restaurantId) ? restaurantId : null;
}

export async function loadPublishedStorefront(restaurantId: string): Promise<PublishedStorefront | null> {
  if (!/^rest_[A-Za-z0-9_-]+$/.test(restaurantId)) return null;
  const { doc, getDoc, db } = await firestore();
  const snap = await getDoc(doc(db, "published", restaurantId));
  if (!snap.exists()) return null;
  return normalizePublishedStorefront(restaurantId, snap.data() as Record<string, unknown>);
}

export async function resolvePublishedStorefront(hostname: string): Promise<PublishedStorefront | null> {
  const restaurantId = await resolveDomainTenant(hostname);
  if (!restaurantId) return null;
  const storefront = await loadPublishedStorefront(restaurantId);
  return storefront ? { ...storefront, resolvedDomain: normalizeDomain(hostname) } : null;
}

export function resolvePublishedPage(storefront: PublishedStorefront, slug: string): CustomPage | null {
  const normalizedSlug = slug === "/" ? "/" : `/${slug.replace(/^\/+/, "").replace(/\/+$/, "")}`;
  return storefront.customPages.find((page) => page.visible && page.slug === normalizedSlug) ?? null;
}
