import assert from "node:assert/strict";
import { readdirSync, readFileSync } from "node:fs";
import { join } from "node:path";
import { test } from "node:test";

// Static C2 guards: public rendering must not touch the private admin Zustand tenant store,
// and private auth/tenant sync must be mounted only under /admin.
const SRC = join(import.meta.dirname, "..");
const read = (rel: string) => readFileSync(join(SRC, rel), "utf8");
const listTsx = (dir: string) => readdirSync(join(SRC, dir)).filter((f) => f.endsWith(".tsx")).map((f) => `${dir}/${f}`);

test("public pages, layout and sections never import the private restaurant store", () => {
  const files = [...listTsx("pages"), ...listTsx("components/layout"), ...listTsx("components/sections")];
  assert.ok(files.length > 10);
  for (const file of files) {
    assert.doesNotMatch(read(file), /store\/restaurantStore/, `${file} must read public data via usePublicStorefront`);
  }
});

test("PublicTenantGate never hydrates, resets, or syncs the private tenant store", () => {
  const app = read("App.tsx");
  const start = app.indexOf("function PublicTenantGate");
  const end = app.indexOf("function Router()");
  assert.ok(start > 0 && end > start);
  const gate = app.slice(start, end);
  assert.doesNotMatch(gate, /hydrateFromTenant|resetTenantState|startTenantSync|useRestaurantStore|forceSyncNow/);
  assert.match(gate, /resolvePublishedStorefront\(window\.location\.hostname\)/);
  assert.match(gate, /PlatformHomepage/);
});

test("AuthProvider (the only caller of startTenantSync) is mounted only under /admin", () => {
  const app = read("App.tsx");
  assert.match(app, /function AuthScope[\s\S]*startsWith\("\/admin"\)\s*\?\s*<AuthProvider>/);
  const appFn = app.slice(app.indexOf("function App()"));
  assert.match(appFn, /<AuthScope>/);
  assert.doesNotMatch(appFn, /<AuthProvider>/);
  for (const file of ["pages", "components/layout", "components/sections"].flatMap(listTsx)) {
    assert.doesNotMatch(read(file), /startTenantSync|scheduleWrite|forceSyncNow|publishCurrentTenant/, file);
  }
});

test("platform hostname bypass is preserved and uses no restaurant id", () => {
  const app = read("App.tsx");
  assert.match(app, /const PLATFORM_HOSTNAME = "restaurant-os-88262\.web\.app";/);
  assert.match(app, /window\.location\.hostname === PLATFORM_HOSTNAME && location === "\/"/);
  assert.doesNotMatch(app, /rest_[A-Za-z0-9]/);
});
