/**
 * C4 — explicit, approved public projection of a tenant.
 *
 * `published/{restaurantId}` is world-readable, so it is built ONLY from allow-listed fields.
 * Never spread the private restaurant document into it. Orders, reservations, visit/activity logs,
 * admin theme, owner identity and notification addresses are intentionally absent.
 */

/** Exact top-level keys allowed in `published/{restaurantId}` (mirrored in firestore.rules). */
export const PUBLISHED_PROJECTION_KEYS = [
  "restaurantId", "config", "siteTheme", "menuItems", "services", "testimonials", "galleryImages",
  "navLinks", "customPages", "quickControls", "sectionMedia", "themeOverrides",
  "bankAccounts", "deliverySettings", "reservationSettings", "publishedAt",
] as const;

/** Public fields of RestaurantConfig. `notificationEmail` is admin-only and is never published. */
const PUBLIC_CONFIG_KEYS = [
  "id", "name", "tagline", "description", "address", "phone", "email", "openingHours", "socials",
  "currency", "currencySymbol", "logo", "favicon", "publicDomain", "heroImage", "googleMapsUrl",
] as const;

/** Bank fields a customer needs to make a manual transfer. */
const PUBLIC_BANK_KEYS = ["id", "bankName", "accountName", "accountNumber", "sortCode", "iban", "swiftBic", "enabled"] as const;

const QUICK_CONTROL_KEYS = ["restaurantOpen", "acceptReservations", "onlineOrders", "whatsapp", "maintenanceMode"] as const;

function pick(source: unknown, keys: readonly string[]): Record<string, unknown> {
  const out: Record<string, unknown> = {};
  if (!source || typeof source !== "object") return out;
  for (const key of keys) {
    const value = (source as Record<string, unknown>)[key];
    if (value !== undefined) out[key] = value;
  }
  return out;
}

const arr = (value: unknown): unknown[] => (Array.isArray(value) ? value : []);
const obj = (value: unknown): Record<string, unknown> =>
  value && typeof value === "object" && !Array.isArray(value) ? (value as Record<string, unknown>) : {};

export function buildPublishedProjection(
  restaurantId: string,
  state: Record<string, unknown>,
  publishedAt: string = new Date().toISOString(),
): Record<string, unknown> {
  return {
    restaurantId,
    config: pick(state.config, PUBLIC_CONFIG_KEYS),
    siteTheme: obj(state.siteTheme),
    menuItems: arr(state.menuItems),
    services: arr(state.services),
    testimonials: arr(state.testimonials),
    galleryImages: arr(state.galleryImages),
    navLinks: arr(state.navLinks),
    customPages: arr(state.customPages),
    quickControls: pick(state.quickControls, QUICK_CONTROL_KEYS),
    sectionMedia: obj(state.sectionMedia),
    themeOverrides: obj(state.themeOverrides),
    // Disabled bank accounts are never published.
    bankAccounts: arr(state.bankAccounts)
      .filter((account) => obj(account).enabled === true)
      .map((account) => pick(account, PUBLIC_BANK_KEYS)),
    deliverySettings: state.deliverySettings ? obj(state.deliverySettings) : null,
    reservationSettings: state.reservationSettings ? obj(state.reservationSettings) : null,
    publishedAt,
  };
}
