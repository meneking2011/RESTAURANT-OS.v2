import { initializeApp } from "firebase/app";
import { getAuth, type Auth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";

// Firebase web config is not secret — it is safe to ship in the client bundle.
// Real access control is enforced by Firestore Security Rules keyed on auth uid.
const firebaseConfig = {
  // Firebase web configuration is public by design; access control belongs in Firestore Rules.
  // Support the project's existing `apiKey` variable and Vite-prefixed variables.
  // Firebase web config is public client configuration. Vercel exposes the
  // configured public key at build time through `apiKey`.
  apiKey:
    import.meta.env.VITE_FIREBASE_API_KEY ||
    import.meta.env.apiKey ||
    "AIzaSyDjcbUbLhTJ9_zt2AR_WaYr96axy61gY68",
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN ?? "restaurant-os-88262.firebaseapp.com",
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID ?? "restaurant-os-88262",
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET ?? "restaurant-os-88262.firebasestorage.app",
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID ?? "194700051652",
  appId: import.meta.env.VITE_FIREBASE_APP_ID ?? "1:194700051652:web:91636a186c9e3c62ecb591",
};

const requiredFirebaseConfig: Array<[string, string | undefined]> = [
  ["VITE_FIREBASE_API_KEY", firebaseConfig.apiKey],
  ["VITE_FIREBASE_AUTH_DOMAIN", firebaseConfig.authDomain],
  ["VITE_FIREBASE_PROJECT_ID", firebaseConfig.projectId],
  ["VITE_FIREBASE_STORAGE_BUCKET", firebaseConfig.storageBucket],
  ["VITE_FIREBASE_MESSAGING_SENDER_ID", firebaseConfig.messagingSenderId],
  ["VITE_FIREBASE_APP_ID", firebaseConfig.appId],
];

export const firebaseConfigError = requiredFirebaseConfig
  .filter(([, value]) => !value?.trim())
  .map(([name]) => name);
export const firebaseConfigured = firebaseConfigError.length === 0;

if (import.meta.env.DEV && firebaseConfigError.length) {
  console.error("[v0] Missing Firebase configuration variables:", firebaseConfigError.join(", "));
}

export const firebaseApp = initializeApp(firebaseConfig);
// Keep the preview usable when Firebase variables have not been added yet.
// Auth actions remain disabled until a real Firebase configuration is present.
export const auth: Auth = firebaseConfigured
  ? getAuth(firebaseApp)
  : (null as unknown as Auth);
export const db = getFirestore(firebaseApp);
export const storage = getStorage(firebaseApp);

/**
 * Every deployment of this app serves exactly one public-facing storefront.
 * That storefront's data always lives under this fixed tenant id in Firestore.
 * The very first person to sign up claims it automatically (see auth.tsx).
 * Any additional signups become fully isolated, independent tenants — data is
 * walled off per restaurantId and ready for a future multi-storefront rollout,
 * but only the "default" tenant is rendered by *this* running app instance.
 */
export const DEFAULT_RESTAURANT_ID = "default";

/** Stable public tenant for this deployed hostname. */
export function getPublicRestaurantId(): string {
  if (typeof window === "undefined") return DEFAULT_RESTAURANT_ID;
  const hostname = window.location.hostname.toLowerCase();
  if (!hostname || hostname === "localhost" || hostname === "127.0.0.1" || hostname.endsWith(".vercel.app")) {
    return DEFAULT_RESTAURANT_ID;
  }
  const safeHost = hostname.replace(/[^a-z0-9-]/g, "-").replace(/-+/g, "-").replace(/^-|-$/g, "");
  return safeHost ? `domain-${safeHost}` : DEFAULT_RESTAURANT_ID;
}
