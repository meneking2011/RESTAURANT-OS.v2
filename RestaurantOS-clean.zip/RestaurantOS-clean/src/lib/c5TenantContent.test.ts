import assert from "node:assert/strict";
import { readdirSync, readFileSync } from "node:fs";
import { join } from "node:path";
import { test } from "node:test";
import {
  CONTENT_COLLECTION_KEYS, contentCollectionPath, contentDocId, fromContentDocs, isInlineMediaUrl, migratedKeys,
  planContentSync, serializeContentDocs, stripInlineMedia, toContentDoc, withoutContentCollections,
} from "./tenantContent.ts";
import { buildPublishedProjection } from "./publishedProjection.ts";

const SRC = join(import.meta.dirname, "..");
const read = (rel: string) => readFileSync(join(SRC, rel), "utf8");
const walk = (dir: string): string[] =>
  readdirSync(join(SRC, dir), { withFileTypes: true }).flatMap((e) =>
    e.isDirectory() ? walk(`${dir}/${e.name}`) : e.name.endsWith(".tsx") || e.name.endsWith(".ts") ? [`${dir}/${e.name}`] : [],
  );
const BLOB = "data:image/png;base64," + "A".repeat(5000);

test("data-URL image blobs are stripped from persisted state; compact URLs are kept", () => {
  const paths: string[] = [];
  const out = stripInlineMedia(
    { config: { logo: BLOB, favicon: "https://res.cloudinary.com/x/a.png" }, menuItems: [{ id: "1", image: BLOB }], tiny: "data:image/svg+xml,%3Csvg%3E" },
    (p) => paths.push(p),
  );
  assert.equal(out.config.logo, "");
  assert.equal(out.config.favicon, "https://res.cloudinary.com/x/a.png");
  assert.equal(out.menuItems[0].image, "");
  assert.equal(out.tiny, "");
  assert.deepEqual(paths, ["config.logo", "menuItems[0].image", "tiny"]);
  assert.ok(isInlineMediaUrl(BLOB));
});

test("tiny data:image URLs are removed regardless of size, at any nesting depth", () => {
  const paths: string[] = [];
  const tiny = "data:image/gif;base64,R0lGOD";
  const out = stripInlineMedia(
    {
      logo: tiny,
      upper: "DATA:IMAGE/PNG;base64,AAAA",
      customPages: [{ id: "p", sections: [{ id: "s", imageUrl: tiny, body: "text mentioning data:image inline" }] }],
      sectionMedia: { hero: { images: [tiny, "https://res.cloudinary.com/demo/image/upload/a.jpg"], backgroundImage: tiny } },
    },
    (p) => paths.push(p),
  );
  assert.equal(out.logo, "");
  assert.equal(out.upper, "");
  assert.equal(out.customPages[0].sections[0].imageUrl, "");
  assert.equal(out.customPages[0].sections[0].body, "text mentioning data:image inline");
  assert.deepEqual(out.sectionMedia.hero.images, ["", "https://res.cloudinary.com/demo/image/upload/a.jpg"]);
  assert.equal(out.sectionMedia.hero.backgroundImage, "");
  assert.equal(paths.length, 5);
  assert.ok(isInlineMediaUrl(tiny));
  assert.equal(isInlineMediaUrl("data:text/plain;base64,QQ=="), false);
});

test("normal Cloudinary / external HTTPS media URLs are preserved", () => {
  const input = {
    config: { logo: "https://res.cloudinary.com/demo/image/upload/v1/restaurant-os/rest_a/media/logo.png", heroImage: "https://images.example.com/hero.jpg" },
    galleryImages: [{ id: "g", src: "https://res.cloudinary.com/demo/image/upload/g.jpg" }],
    logoIcon: "flame",
  };
  assert.deepEqual(stripInlineMedia(input), input);
});

test("tenantSync strips inline media before every tenant write and publish", () => {
  const sync = read("lib/tenantSync.ts");
  assert.match(sync, /stripInlineMedia\(/);
  assert.match(sync, /function getSanitizedState[\s\S]*stripInlineMedia/);
});

test("no admin upload path converts images to base64 (readAsDataURL)", () => {
  for (const file of [...walk("admin"), ...walk("pages"), ...walk("components"), ...walk("store")]) {
    assert.doesNotMatch(read(file), /readAsDataURL/, `${file} must upload through the media provider`);
  }
});

test("content subcollection paths are restaurant-scoped and require a restaurantId", () => {
  for (const key of CONTENT_COLLECTION_KEYS) {
    assert.deepEqual(contentCollectionPath("rest_a", key), ["restaurants", "rest_a", key]);
  }
  assert.throws(() => contentCollectionPath("", "menuItems"));
  const sync = read("lib/tenantSync.ts");
  assert.doesNotMatch(sync, /collection\(db, "(menuItems|galleryImages|customPages|testimonials)"/);
  assert.doesNotMatch(read("lib/tenantContent.ts"), /rest_[A-Za-z0-9]|DEFAULT_RESTAURANT_ID|"default"/);
});

test("content docs round-trip in order and sync writes only what changed", () => {
  const items = [{ id: "b", n: 1 }, { id: "a/x", n: 2 }];
  const first = planContentSync(new Map(), items);
  assert.equal(first.ops.length, 2);
  const docs = first.ops.map((op) => ({ id: op.id, data: (op as { data: Record<string, unknown> }).data }));
  assert.deepEqual(fromContentDocs([...docs].reverse()), items);
  assert.ok(!contentDocId(items[1], 1).includes("/"));
  // Firestore may return keys in a different order: must still be recognised as unchanged.
  const reordered = docs.map((d) => ({ id: d.id, data: Object.fromEntries(Object.entries(d.data).reverse()) }));
  assert.equal(planContentSync(serializeContentDocs(reordered), items).ops.length, 0);
  // Removing an item deletes only that document; editing one rewrites only that document.
  const removed = planContentSync(first.next, [items[0]]);
  assert.deepEqual(removed.ops.map((o) => o.type), ["delete"]);
  const edited = planContentSync(first.next, [{ id: "b", n: 9 }, items[1]]);
  assert.equal(edited.ops.length, 1);
  assert.equal(toContentDoc(items[0], 0)._order, 0);
});

test("tenant document no longer carries the moved lists; legacy tenants are detected", () => {
  const rest = withoutContentCollections({ config: {}, menuItems: [1], galleryImages: [1], customPages: [1], testimonials: [1], services: [1] });
  assert.deepEqual(Object.keys(rest).sort(), ["config", "services"]);
  assert.deepEqual(migratedKeys({ menuItems: [1] }), []);
  assert.deepEqual(migratedKeys({ contentCollections: { menuItems: true, customPages: true } }), ["menuItems", "customPages"]);
});

test("migration is copy → mark → delete legacy, in that order, and never deletes the tenant", () => {
  const sync = read("lib/tenantSync.ts");
  const fn = sync.slice(sync.indexOf("async function persistTenantState"), sync.indexOf("function isActiveTenantContext"));
  assert.ok(fn.indexOf("batch.commit()") < fn.indexOf("markerFor("), "subcollections must be committed before the marker");
  assert.ok(fn.indexOf("markerFor(") < fn.indexOf("deleteField()"));
  assert.match(fn, /stillActive\(\)/);
  assert.match(sync, /migratedKeys\(docCache\)\.length < CONTENT_COLLECTION_KEYS\.length/);
});

test("tenant ownership: rules tie content subcollections to owners/{uid}.restaurantId", () => {
  const rules = read("../firestore.rules");
  const start = rules.indexOf("match /{contentCollection}/{docId}");
  assert.ok(start > 0, "content subcollection rule missing");
  const block = rules.slice(start, rules.indexOf("}", rules.indexOf("allow", start)));
  assert.match(block, /contentCollection in \['menuItems', 'galleryImages', 'customPages', 'testimonials'\]/);
  assert.match(block, /ownsRestaurant\(restaurantId\)/);
  assert.doesNotMatch(block, /allow [a-z, ]*: if true/);
  assert.match(rules, /function ownsRestaurant[\s\S]*owners\/\$\(request\.auth\.uid\)[\s\S]*\.restaurantId == restaurantId/);
  // Tenant doc may carry the migration marker; published allow-list is not widened by C5.
  assert.match(rules, /'themeOverrides', 'sectionMedia', 'contentCollections'/);
  const published = rules.slice(rules.indexOf("match /published/{restaurantId}"), rules.indexOf("match /restaurants/{restaurantId}"));
  assert.doesNotMatch(published, /contentCollections|_order/);
  // C3 customer collections are still present and untouched.
  for (const c of ["orders", "orderReceipts", "reservations", "contactMessages", "reviewSubmissions"]) assert.ok(rules.includes(`match /${c}/`), c);
});

test("published projection still carries the public lists assembled from the logical state", () => {
  const state = {
    config: { name: "A" }, siteTheme: {}, menuItems: [{ id: "m" }], galleryImages: [{ id: "g" }],
    customPages: [{ id: "p" }], testimonials: [{ id: "t" }], services: [{ id: "s" }], navLinks: [], quickControls: {},
  };
  const p = buildPublishedProjection("rest_a", state, "t");
  assert.equal((p.menuItems as unknown[]).length, 1);
  assert.equal((p.galleryImages as unknown[]).length, 1);
  assert.equal((p.customPages as unknown[]).length, 1);
  assert.equal((p.testimonials as unknown[]).length, 1);
  assert.equal("contentCollections" in p, false);
  assert.equal("_order" in ((p.menuItems as object[])[0]), false);
  const sync = read("lib/tenantSync.ts");
  assert.match(sync, /buildPublishedProjection\(restaurantId, validatedState\)/);
});

test("public code never reads private tenant documents or content subcollections", () => {
  const publicFiles = [
    ...walk("pages"), ...walk("components"),
    "lib/publicStorefront.ts", "lib/publicStorefrontContext.tsx", "lib/publicSubmissions.ts",
  ].filter((f) => !f.includes("/ui/"));
  for (const file of publicFiles) {
    const src = read(file);
    assert.doesNotMatch(src, /tenantContent|tenantSync|CONTENT_COLLECTION_KEYS/, `${file} must not use private content storage`);
    assert.doesNotMatch(src, /getDocs?\([^)]*"restaurants"|collection\([^)]*"restaurants"|onSnapshot/, `${file} must not read restaurants/*`);
  }
  const app = read("App.tsx");
  assert.doesNotMatch(app.slice(app.indexOf("function PublicTenantGate"), app.indexOf("function Router()")), /tenantSync|tenantContent/);
});
