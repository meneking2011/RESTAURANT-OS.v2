export type UploadedMedia = {
  assetId: string;
  publicId: string;
  secureUrl: string;
  format: string;
  bytes: number;
  width?: number;
  height?: number;
  originalFilename?: string;
};

const cloudName = import.meta.env.VITE_CLOUDINARY_CLOUD_NAME as string | undefined;
const uploadPreset = import.meta.env.VITE_CLOUDINARY_UPLOAD_PRESET as string | undefined;

export const cloudinaryConfigError = [
  !cloudName && "VITE_CLOUDINARY_CLOUD_NAME",
  !uploadPreset && "VITE_CLOUDINARY_UPLOAD_PRESET",
].filter(Boolean) as string[];

export async function uploadRestaurantMedia(file: File, restaurantId: string, onProgress?: (value: number) => void): Promise<UploadedMedia> {
  if (cloudinaryConfigError.length) throw new Error(`Cloudinary is not configured: ${cloudinaryConfigError.join(", ")}`);
  const body = new FormData();
  body.append("file", file);
  body.append("upload_preset", uploadPreset!);
  body.append("folder", `restaurant-os/${restaurantId}/media`);
  body.append("context", `restaurantId=${restaurantId}|alt=${file.name}`);

  return await new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open("POST", `https://api.cloudinary.com/v1_1/${encodeURIComponent(cloudName!)}/image/upload`);
    xhr.upload.onprogress = (event) => {
      if (event.lengthComputable) onProgress?.(Math.round((event.loaded / event.total) * 100));
    };
    xhr.onerror = () => reject(new Error("Cloudinary upload failed because the network request failed."));
    xhr.onload = () => {
      try {
        const result = JSON.parse(xhr.responseText) as Record<string, unknown>;
        if (xhr.status < 200 || xhr.status >= 300 || typeof result.secure_url !== "string") {
          reject(new Error(typeof result.error === "object" && result.error && "message" in result.error ? String(result.error.message) : "Cloudinary rejected the upload."));
          return;
        }
        resolve({
          assetId: String(result.asset_id ?? result.public_id),
          publicId: String(result.public_id),
          secureUrl: result.secure_url,
          format: String(result.format ?? file.type),
          bytes: Number(result.bytes ?? file.size),
          width: typeof result.width === "number" ? result.width : undefined,
          height: typeof result.height === "number" ? result.height : undefined,
          originalFilename: typeof result.original_filename === "string" ? result.original_filename : file.name,
        });
      } catch {
        reject(new Error("Cloudinary returned an invalid upload response."));
      }
    };
    xhr.send(body);
  });
}

export async function deleteRestaurantMedia(_publicId: string): Promise<void> {
  // Cloudinary deletion requires an authenticated server-side destroy request. The
  // library detaches the asset from this tenant immediately; cleanup can be handled
  // by the future signed media service without exposing an API secret in the browser.
}

/**
 * C5: validated image upload for admin editors. Returns only the compact Cloudinary URL that gets
 * stored in tenant state — image bytes/base64 are never written to Firestore.
 */
export async function uploadTenantImage(file: File, restaurantId: string | null, onProgress?: (value: number) => void): Promise<string> {
  if (!restaurantId) throw new Error("No active restaurant. Please sign in again.");
  if (!file.type.startsWith("image/")) throw new Error(`${file.name} is not a supported image.`);
  if (file.size > 10 * 1024 * 1024) throw new Error(`${file.name} is larger than the 10 MB limit.`);
  return (await uploadRestaurantMedia(file, restaurantId, onProgress)).secureUrl;
}
