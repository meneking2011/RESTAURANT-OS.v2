import { createContext, useContext, useEffect, useRef, useState, ReactNode } from "react";
import {
  onAuthStateChanged,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signInWithPopup,
  signInWithRedirect,
  getRedirectResult,
  sendPasswordResetEmail,
  setPersistence,
  browserLocalPersistence,
  GoogleAuthProvider,
  signOut,
  User,
} from "firebase/auth";
import { doc, getDoc } from "firebase/firestore";
import { auth, db, firebaseConfigured, firebaseConfigError } from "./firebase";
import { startTenantSync, stopTenantSync } from "./tenantSync";
import { useRestaurantStore } from "@/store/restaurantStore";

interface AuthContextValue {
  user: User | null;
  restaurantId: string | null;
  /** True until Firebase auth and the authorized tenant are fully initialized. */
  loading: boolean;
  authInitialized: boolean;
  error: string | null;
  login: (email: string, password: string) => Promise<void>;
  signup: (email: string, password: string) => Promise<void>;
  loginWithGoogle: () => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

/** Resolve only an explicitly assigned owner tenant. Never claim or invent one at sign-in. */
async function resolveRestaurantId(uid: string): Promise<string> {
  console.log("[RestaurantOS/Auth] owner lookup", { uid });
  let ownerSnap;
  try {
    ownerSnap = await getDoc(doc(db, "owners", uid));
  } catch (err) {
    const code = (err as { code?: string })?.code;
    console.error("[RestaurantOS/Auth] owner lookup failure", { uid, code, message: (err as { message?: string })?.message });
    throw new Error(`Owner lookup failed${code ? ` (${code})` : ""}`, { cause: err });
  }
  if (!ownerSnap.exists()) {
    console.error("[RestaurantOS/Auth] owner lookup missing", { uid });
    throw new Error("Your account is not linked to a restaurant owner record.");
  }
  const assignedId = ownerSnap.data().restaurantId;
  const normalizedId = typeof assignedId === "string" ? assignedId.trim() : "";
  // Existing production owner mappings may use UUIDs as well as the newer rest_* IDs.
  // Preserve the exact assigned tenant; reject only empty, default-like, or unsafe values.
  if (!normalizedId || normalizedId === "default" || !/^[A-Za-z0-9_-]+$/.test(normalizedId)) {
    console.error("[RestaurantOS/Auth] owner lookup malformed", { uid, restaurantId: assignedId });
    throw new Error("Owner record is missing a valid restaurantId");
  }
  console.log("[RestaurantOS/Auth] owner lookup success", { uid, restaurantId: normalizedId });
  return normalizedId;
}

function mapAuthError(code?: string): string {
  switch (code) {
    case "auth/invalid-email": return "Enter a valid email address.";
    case "auth/user-not-found": return "No account was found for that email.";
    case "auth/wrong-password": return "The password is incorrect.";
    case "auth/invalid-credential": return "The email or password is incorrect.";
    case "auth/email-already-in-use": return "An account with that email already exists.";
    case "auth/weak-password": return "Password must be at least 8 characters.";
    case "auth/too-many-requests": return "Too many attempts. Please wait before trying again.";
    case "auth/network-request-failed": return "Network error. Check your connection and retry.";
    case "auth/unauthorized-domain": return "This website domain is not authorized in Firebase Authentication. Add the exact domain in Firebase Console.";
    case "auth/operation-not-allowed": return "This Firebase Authentication provider is disabled. Enable Email/Password or Google in Firebase Console.";
    default: return "Authentication failed. Please retry.";
  }
}

function authErrorMessage(err: unknown): string {
  const code = (err as { code?: string })?.code;
  if (import.meta.env.DEV) console.error("[v0] Firebase auth error", code, (err as { message?: string })?.message);
  return mapAuthError(code);
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [restaurantId, setRestaurantId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [authInitialized, setAuthInitialized] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const authEvent = useRef(0);
  const persistenceReady = useRef<Promise<void> | null>(null);

  useEffect(() => {
    if (!firebaseConfigured) {
      setLoading(false);
      setError(`Firebase configuration is incomplete: ${firebaseConfigError.join(", ")}.`);
      return;
    }

    let unsubscribe = () => {};
    let disposed = false;

    // Establish durable browser persistence before subscribing to auth state or
    // starting a sign-in flow. Starting the listener first can briefly publish a
    // signed-out state and redirect the admin route during Google OAuth.
    const initializeAuth = async () => {
      console.log("[RestaurantOS/Auth] auth initialization start");
      try {
        persistenceReady.current = setPersistence(auth, browserLocalPersistence);
        await persistenceReady.current;
        console.log("[RestaurantOS/Auth] persistence initialized");
      } catch (err) {
        console.error("[v0] Failed to persist Firebase session:", err);
      }

      if (disposed) return;
      // Subscribe before resolving OAuth redirects. This prevents the router from
      // observing a transient signed-out state and sending a returning user back
      // to /admin/login before Firebase has restored the redirect session.
      unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
        const eventId = ++authEvent.current;
        console.log("[RestaurantOS/Auth] onAuthStateChanged", { eventId, authenticated: Boolean(firebaseUser), uid: firebaseUser?.uid });
        setError(null);
        setLoading(true);
        let tenantResolved = false;
        try {
          if (!firebaseUser) {
            // Firebase may emit a stale signed-out callback while persistence is
            // restoring. Only clear tenant state after initial auth resolution
            // confirms there is still no current user.
            if (auth.currentUser) {
              if (import.meta.env.DEV) console.log("[v0] ignored stale signed-out auth event");
              return;
            }
            setAuthInitialized(true);
            stopTenantSync();
            useRestaurantStore.getState().resetTenantState();
            setUser(null);
            setRestaurantId(null);
            return;
          }
          const rid = await resolveRestaurantId(firebaseUser.uid);
          console.log("[RestaurantOS/Auth] owner restaurant resolved", { uid: firebaseUser.uid, restaurantId: rid });
          if (eventId !== authEvent.current || auth.currentUser?.uid !== firebaseUser.uid) return;
          setAuthInitialized(true);
          setUser(firebaseUser);
          setRestaurantId(rid);
          tenantResolved = true;
        } catch (err) {
          if (eventId !== authEvent.current) return;
          const code = (err as { code?: string })?.code;
          const message = (err as { message?: string })?.message;
          console.error("[RestaurantOS/Auth] authentication tenant resolution failed", { uid: firebaseUser.uid, code, message });
          setError(code?.startsWith("auth/") ? authErrorMessage(err) : "Authentication succeeded, but restaurant data could not be loaded. Check your connection and retry.");
          setUser(firebaseUser);
          setRestaurantId(null);
        } finally {
          // Keep the admin guard in its loading state until the tenant-sync effect
          // has hydrated the private store, rather than briefly rendering a
          // dashboard that can be replaced by a sync failure.
          setLoading(Boolean(firebaseUser && restaurantId));
        }
      });

      try {
        await getRedirectResult(auth);
      } catch (err) {
        if (!disposed) {
          const code = (err as { code?: string })?.code;
          setError(authErrorMessage(err));
        }
      }
    };

    void initializeAuth();
    return () => {
      disposed = true;
      unsubscribe();
      stopTenantSync();
    };
  }, []);

  useEffect(() => {
    if (!authInitialized || !user || !restaurantId) return;
    let cancelled = false;
    setLoading(true);
    console.log("[RestaurantOS/Tenant] tenant sync start", { uid: user.uid, restaurantId });
    void startTenantSync(restaurantId, user.uid)
      .catch((err) => {
        if (!cancelled) {
          setError("Authentication succeeded, but restaurant data could not be loaded. Check your connection and retry.");
          setRestaurantId(null);
        }
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
      console.log("[RestaurantOS/Tenant] tenant sync stop", { uid: user.uid, restaurantId });
      stopTenantSync();
    };
  }, [authInitialized, user, restaurantId]);

  const login = async (email: string, password: string) => {
    if (!firebaseConfigured) throw new Error("Firebase is not configured.");
    setError(null);
    try {
      if (persistenceReady.current) await persistenceReady.current;
      await signInWithEmailAndPassword(auth, email, password);
    } catch (err) {
      const code = (err as { code?: string })?.code;
      setError(authErrorMessage(err));
      throw err;
    }
  };

  const signup = async (email: string, password: string) => {
    if (!firebaseConfigured) throw new Error("Firebase is not configured.");
    setError(null);
    try {
      await createUserWithEmailAndPassword(auth, email, password);
    } catch (err) {
      const code = (err as { code?: string })?.code;
      setError(authErrorMessage(err));
      throw err;
    }
  };

  const resetPassword = async (email: string) => {
    if (!firebaseConfigured) throw new Error("Firebase is not configured.");
    setError(null);
    try {
      await sendPasswordResetEmail(auth, email.trim());
    } catch (err) {
      const code = (err as { code?: string })?.code;
      setError(code === "auth/user-not-found" ? "No registered account was found for that email." : mapAuthError(code));
      throw err;
    }
  };

  const loginWithGoogle = async () => {
    if (!firebaseConfigured) throw new Error("Firebase is not configured.");
    setError(null);
    const provider = new GoogleAuthProvider();
    provider.addScope("email");
    provider.addScope("profile");
    provider.setCustomParameters({ prompt: "select_account" });

    try {
      if (persistenceReady.current) await persistenceReady.current;
      // Try popup first (works in standalone browser windows)
      await signInWithPopup(auth, provider);
    } catch (err) {
      const code = (err as { code?: string })?.code;

      if (code === "auth/popup-blocked") {
        // Only a genuinely blocked popup should fall back to redirect. A user
        // closing the popup must not start a redirect loop back to /admin.
        await signInWithRedirect(auth, provider);
        return;
      }

      // Any other error: show it
      if (code !== "auth/cancelled-popup-request") {
        setError(authErrorMessage(err));
      }
      throw err;
    }
  };

  const logout = async () => {
    await signOut(auth);
  };

  return (
    <AuthContext.Provider value={{ user, restaurantId, loading, authInitialized, error, login, signup, loginWithGoogle, resetPassword, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

/** Safe fallback so no component ever crashes if accidentally rendered outside AuthProvider. */
const AUTH_FALLBACK: AuthContextValue = {
  user: null,
  restaurantId: null,
  loading: true,
  authInitialized: false,
  error: null,
  login: async () => { throw new Error("AuthProvider not mounted"); },
  signup: async () => { throw new Error("AuthProvider not mounted"); },
  loginWithGoogle: async () => { throw new Error("AuthProvider not mounted"); },
  resetPassword: async () => { throw new Error("AuthProvider not mounted"); },
  logout: async () => {},
};

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    if (import.meta.env.DEV) {
      console.error(
        "[RestaurantOS] useAuth() called outside <AuthProvider>. " +
        "All components must be rendered inside the provider. Returning safe defaults."
      );
    }
    return AUTH_FALLBACK;
  }
  return ctx;
}
