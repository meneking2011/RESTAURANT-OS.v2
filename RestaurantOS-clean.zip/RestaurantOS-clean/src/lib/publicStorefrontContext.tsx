import { createContext, useContext, useEffect, useRef, useState, type ReactNode } from "react";
import { doc, getDoc } from "firebase/firestore";
import { db, firebaseConfigured } from "./firebase";
import { useAuth } from "./auth";
import type { PublishedStorefront } from "./publicStorefront";
import { loadPublishedStorefront } from "./publicStorefront";

type PublicSelector<T> = (storefront: PublishedStorefront) => T;
const PublicStorefrontContext = createContext<PublishedStorefront | null>(null);

type PlatformState = {
  storefront: PublishedStorefront | null;
  loading: boolean;
  error: string | null;
};
const PlatformStorefrontContext = createContext<PlatformState>({ storefront: null, loading: false, error: null });

export function PublicStorefrontProvider({ storefront, children }: { storefront: PublishedStorefront; children: ReactNode }) {
  return <PublicStorefrontContext.Provider value={storefront}>{children}</PublicStorefrontContext.Provider>;
}

export function usePlatformStorefront() {
  return useContext(PlatformStorefrontContext);
}

/**
 * Public selection for the Firebase-hosted platform hostname. This is deliberately
 * separate from AuthProvider and the private Zustand tenant store: auth can select
 * a published tenant, but signing out never clears the already-selected storefront.
 */
export function PlatformStorefrontProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<PlatformState>({ storefront: null, loading: false, error: null });
  const generation = useRef(0);
  const { user, authInitialized } = useAuth();

  useEffect(() => {
    if (!firebaseConfigured || window.location.hostname !== "restaurant-os-88262.web.app" || !authInitialized) return;
    setState((current) => ({ ...current, loading: true, error: null }));
    const currentGeneration = ++generation.current;
    if (!user) {
      setState({ storefront: null, loading: false, error: null });
      return;
    }
    void (async () => {
      try {
        const ownerSnapshot = await getDoc(doc(db, "owners", user.uid));
        const restaurantId = ownerSnapshot.data()?.restaurantId;
        if (typeof restaurantId !== "string" || !/^rest_[A-Za-z0-9_-]+$/.test(restaurantId)) {
          throw new Error("Your owner account is not linked to a valid restaurant.");
        }
        const storefront = await loadPublishedStorefront(restaurantId);
        if (currentGeneration !== generation.current) return;
        if (!storefront) throw new Error("This restaurant has not published a storefront yet.");
        setState({ storefront, loading: false, error: null });
      } catch (error) {
        if (currentGeneration !== generation.current) return;
        setState((current) => ({ ...current, loading: false, error: error instanceof Error ? error.message : "Unable to load the published storefront." }));
      }
    })();
  }, [authInitialized, user]);

  return <PlatformStorefrontContext.Provider value={state}>{children}</PlatformStorefrontContext.Provider>;
}

export function usePublicStorefront<T = PublishedStorefront>(selector?: PublicSelector<T>): T {
  const storefront = useContext(PublicStorefrontContext);
  if (!storefront) throw new Error("Public storefront is not initialized.");
  return (selector ? selector(storefront) : storefront) as T;
}

export function usePublicStorefrontOptional(): PublishedStorefront | null {
  return useContext(PublicStorefrontContext);
}
