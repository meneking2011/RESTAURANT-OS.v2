/**
 * C5 — tenant content storage helpers (pure, Firebase-free so they are unit-testable).
 *
 * High-growth lists (menu, gallery, custom pages, testimonials) live in restaurant-scoped
 * subcollections `restaurants/{restaurantId}/{key}/{docId}` instead of arrays inside the tenant
 * document (1 MiB limit). Small/bounded fields stay in the tenant document. Customer records
 * (C3) are unrelated and untouched. Public pages never read any of this: the owner-side publish
 * step assembles `published/{restaurantId}` (C4) from the logical store state.
 */

export const CONTENT_COLLECTION_KEYS = ["menuItems", "galleryImages", "customPages", "testimonials"] as const;
export type ContentCollectionKey = (typeof CONTENT_COLLECTION_KEYS)[number];

/** Marker field on the tenant doc: `{ menuItems: true, ... }` means that list lives in its subcollection. */
export const CONTENT_MARKER_FIELD = "contentCollections";
export const ORDER_FIELD = "_order";

export function contentCollectionPath(restaurantId: string, key: ContentCollectionKey): [string, string, string] {
  if (!restaurantId) throw new Error("A restaurantId is required for tenant content paths.");
  return ["restaurants", restaurantId, key];
}

/** Firestore-safe, stable document id for an item. */
export function contentDocId(item: unknown, index: number): string {
  const id = item && typeof item === "object" ? (item as { id?: unknown }).id : undefined;
  return typeof id === "string" && id ? `i_${encodeURIComponent(id)}`.slice(0, 500) : `idx_${index}`;
}

// ── Inline media guard ──────────────────────────────────────────────────────

/** Any `data:image/...` URL, of any size, is inline image data and must never be persisted. */
export const isInlineMediaUrl = (value: unknown): value is string =>
  typeof value === "string" && /^\s*data:image\//i.test(value);

/**
 * Recursively drops every `data:image/...` URL (any size, any nesting) so they are never persisted into tenant or published
 * documents. Images must be uploaded via the media provider and stored as URLs.
 */
export function stripInlineMedia<T>(value: T, onStrip?: (path: string) => void, path = ""): T {
  if (isInlineMediaUrl(value)) {
    onStrip?.(path);
    return "" as unknown as T;
  }
  if (Array.isArray(value)) return value.map((v, i) => stripInlineMedia(v, onStrip, `${path}[${i}]`)) as unknown as T;
  if (value && typeof value === "object") {
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(value as Record<string, unknown>)) out[k] = stripInlineMedia(v, onStrip, path ? `${path}.${k}` : k);
    return out as T;
  }
  return value;
}

// ── State splitting / composition ───────────────────────────────────────────

/** Tenant-document part of a logical state: everything except the subcollection lists. */
export function withoutContentCollections(state: Record<string, unknown>): Record<string, unknown> {
  const out = { ...state };
  for (const key of CONTENT_COLLECTION_KEYS) delete out[key];
  return out;
}

export function contentItems(state: Record<string, unknown>, key: ContentCollectionKey): unknown[] {
  return Array.isArray(state[key]) ? (state[key] as unknown[]) : [];
}

export function toContentDoc(item: unknown, index: number): Record<string, unknown> {
  const base = item && typeof item === "object" ? (item as Record<string, unknown>) : { value: item };
  return { ...base, [ORDER_FIELD]: index };
}

export function fromContentDocs(docs: { data: Record<string, unknown> }[]): unknown[] {
  return docs
    .slice()
    .sort((a, b) => Number(a.data[ORDER_FIELD] ?? 0) - Number(b.data[ORDER_FIELD] ?? 0))
    .map(({ data }) => {
      const { [ORDER_FIELD]: _o, ...item } = data;
      return item;
    });
}

/** JSON with sorted keys, so Firestore's key ordering can never make an identical document look changed. */
export function stableStringify(value: unknown): string {
  if (Array.isArray(value)) return `[${value.map(stableStringify).join(",")}]`;
  if (value && typeof value === "object") {
    const o = value as Record<string, unknown>;
    return `{${Object.keys(o).sort().map((k) => `${JSON.stringify(k)}:${stableStringify(o[k])}`).join(",")}}`;
  }
  return JSON.stringify(value) ?? "null";
}

export function sameSerialized(a: Map<string, string> | undefined, b: Map<string, string> | undefined): boolean {
  if (!a || !b || a.size !== b.size) return false;
  for (const [k, v] of a) if (b.get(k) !== v) return false;
  return true;
}

export type ContentOp = { type: "set"; id: string; data: Record<string, unknown> } | { type: "delete"; id: string };

/** Minimal set of writes turning `previous` (docId → serialized doc) into the desired list. */
export function planContentSync(previous: Map<string, string>, items: unknown[]): { ops: ContentOp[]; next: Map<string, string> } {
  const ops: ContentOp[] = [];
  const next = new Map<string, string>();
  items.forEach((item, index) => {
    const id = contentDocId(item, index);
    const data = toContentDoc(item, index);
    const serialized = stableStringify(data);
    next.set(id, serialized);
    if (previous.get(id) !== serialized) ops.push({ type: "set", id, data });
  });
  for (const id of previous.keys()) if (!next.has(id)) ops.push({ type: "delete", id });
  return { ops, next };
}

export function serializeContentDocs(docs: { id: string; data: Record<string, unknown> }[]): Map<string, string> {
  return new Map(docs.map((d) => [d.id, stableStringify(d.data)]));
}

export function markerFor(keys: readonly ContentCollectionKey[]): Record<string, true> {
  return Object.fromEntries(keys.map((k) => [k, true as const]));
}

export function migratedKeys(docData: Record<string, unknown>): ContentCollectionKey[] {
  const marker = docData[CONTENT_MARKER_FIELD];
  if (!marker || typeof marker !== "object") return [];
  return CONTENT_COLLECTION_KEYS.filter((k) => (marker as Record<string, unknown>)[k] === true);
}
