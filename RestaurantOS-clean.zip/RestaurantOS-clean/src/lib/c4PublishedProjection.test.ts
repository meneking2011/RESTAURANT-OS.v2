import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { join } from "node:path";
import { test } from "node:test";
import { buildPublishedProjection, PUBLISHED_PROJECTION_KEYS } from "./publishedProjection.ts";

const SRC = join(import.meta.dirname, "..");
const state = {
  config: { id: "rest_a", name: "A", notificationEmail: "secret@x.com", ownerUid: "u1", phone: "1" },
  siteTheme: { primaryHex: "#fff" },
  adminTheme: { x: 1 },
  menuItems: [{ id: "m" }],
  quickControls: { restaurantOpen: true, extra: 1 },
  sectionMedia: { hero: { images: [] } },
  themeOverrides: { menu: {} },
  bankAccounts: [
    { id: "1", bankName: "B", accountNumber: "1", enabled: true, internalNote: "x" },
    { id: "2", bankName: "C", accountNumber: "2", enabled: false },
  ],
  orders: [{ id: "o" }],
  reservations: [{ id: "r" }],
  visitLog: [1],
  activityLog: [1],
  ownerUid: "u1",
};

test("projection contains only approved keys and no private data", () => {
  const p = buildPublishedProjection("rest_a", state, "t");
  for (const k of Object.keys(p)) assert.ok((PUBLISHED_PROJECTION_KEYS as readonly string[]).includes(k), k);
  for (const k of ["orders", "reservations", "visitLog", "activityLog", "adminTheme", "ownerUid"]) assert.equal(k in p, false, k);
  assert.equal("notificationEmail" in (p.config as object), false);
  assert.equal("ownerUid" in (p.config as object), false);
  assert.deepEqual(p.quickControls, { restaurantOpen: true });
});

test("projection includes section media, theme overrides and only enabled bank accounts", () => {
  const p = buildPublishedProjection("rest_a", state, "t");
  assert.deepEqual(p.sectionMedia, state.sectionMedia);
  assert.deepEqual(p.themeOverrides, state.themeOverrides);
  assert.equal((p.bankAccounts as unknown[]).length, 1);
  assert.equal("internalNote" in (p.bankAccounts as object[])[0], false);
});

test("removed fields do not survive: projection is rebuilt from scratch", () => {
  const p = buildPublishedProjection("rest_a", { ...state, sectionMedia: undefined, bankAccounts: [] }, "t");
  assert.deepEqual(p.sectionMedia, {});
  assert.deepEqual(p.bankAccounts, []);
});

test("publish uses the projection builder without merge; rules allow-list matches", () => {
  const sync = readFileSync(join(SRC, "lib/tenantSync.ts"), "utf8");
  assert.match(sync, /buildPublishedProjection\(restaurantId, validatedState\)/);
  assert.match(sync, /setDoc\(doc\(db, "published", restaurantId\), publicProjection\)/);
  const rules = readFileSync(join(SRC, "../firestore.rules"), "utf8");
  const block = rules.slice(rules.indexOf("match /published/{restaurantId}"), rules.indexOf("match /restaurants/{restaurantId}"));
  for (const k of PUBLISHED_PROJECTION_KEYS) assert.ok(block.includes(`'${k}'`), `rules missing ${k}`);
});
