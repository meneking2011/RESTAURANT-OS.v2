/**
 * C3 — public customer submissions (orders, order receipts, reservations, contact messages, review
 * submissions).
 *
 * Tenant isolation rules for this module:
 *  - Every function takes the resolved `PublishedStorefront` (hostname → domains/{host} →
 *    published/{restaurantId} → PublicStorefrontProvider). The restaurant id and domain are read
 *    from it; callers can never pass a restaurant id.
 *  - No private admin store, no owner auth, no browser-stored tenant, no default/first restaurant.
 *  - This module never imports the admin tenant-sync module and never touches the admin store.
 *
 * Firestore rules (firestore.rules) independently enforce that each document is create-only, is
 * shaped exactly as below, targets a published restaurant and carries a domain that maps to it.
 */
import type { Order, OrderItem } from "@/types/restaurant";
import type { PublishedStorefront } from "./publicStorefront";

const RESTAURANT_ID_RE = /^rest_[A-Za-z0-9_-]+$/;

export const RECEIPT_FILE_NAME = "receipt";
export const RECEIPT_ALLOWED_TYPES = ["image/jpeg", "image/png", "image/webp", "application/pdf"] as const;
export const RECEIPT_MAX_BYTES = 10 * 1024 * 1024;

export const receiptStoragePath = (restaurantId: string, orderId: string) =>
  `restaurants/${restaurantId}/receipts/${orderId}/${RECEIPT_FILE_NAME}`;

type Tenant = { restaurantId: string; domain: string };

function tenantOf(storefront: PublishedStorefront): Tenant {
  const restaurantId = storefront.restaurantId;
  const domain = storefront.resolvedDomain;
  if (!RESTAURANT_ID_RE.test(restaurantId) || !domain) {
    throw new Error("This storefront could not be verified. Please reload the page and try again.");
  }
  return { restaurantId, domain };
}

/** 128-bit unguessable id, e.g. `ord-3f9c…` (32 hex chars). */
export function createSubmissionId(prefix: "ord" | "res" | "msg" | "rev"): string {
  const bytes = new Uint8Array(16);
  crypto.getRandomValues(bytes);
  return `${prefix}-${Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("")}`;
}

/** Drop undefined/empty optional values — Firestore rejects undefined and rules reject unexpected keys. */
function compact<T extends Record<string, unknown>>(value: T): T {
  const out: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(value)) {
    if (v === undefined || v === null) continue;
    if (typeof v === "string" && v === "") continue;
    out[k] = v;
  }
  return out as T;
}

async function fs() {
  const [firestore, { db }] = await Promise.all([import("firebase/firestore"), import("./firebase")]);
  return { ...firestore, db };
}

// ── Orders ────────────────────────────────────────────────────────────────────

export type NewOrderInput = {
  customerName: string;
  email: string;
  phone: string;
  deliveryAddress: string;
  specialNotes?: string;
  items: OrderItem[];
  selectedBankAccountId?: string;
  subtotal: number;
  deliveryFee: number;
  tax: number;
  totalAmount: number;
};

/** Creates `restaurants/{tenant}/orders/{id}`. Returns the persisted order (same shape checkout already used). */
export async function submitPublicOrder(storefront: PublishedStorefront, input: NewOrderInput): Promise<Order> {
  const { restaurantId, domain } = tenantOf(storefront);
  const { doc, setDoc, serverTimestamp, db } = await fs();
  const id = createSubmissionId("ord");
  const orderedAt = new Date().toISOString();
  const order: Order = {
    id,
    customerName: input.customerName,
    email: input.email,
    phone: input.phone,
    deliveryAddress: input.deliveryAddress,
    ...(input.specialNotes ? { specialNotes: input.specialNotes } : {}),
    items: input.items.map((i) => ({ menuItemId: i.menuItemId, name: i.name, quantity: i.quantity, price: i.price })),
    paymentMethod: "bankTransfer",
    ...(input.selectedBankAccountId ? { selectedBankAccountId: input.selectedBankAccountId } : {}),
    paymentStatus: "pending_receipt",
    status: "new",
    subtotal: input.subtotal,
    deliveryFee: input.deliveryFee,
    tax: input.tax,
    totalAmount: input.totalAmount,
    orderedAt,
  };
  await setDoc(doc(db, "restaurants", restaurantId, "orders", id), {
    ...order,
    restaurantId,
    domain,
    submittedAt: serverTimestamp(),
  });
  return order;
}

/**
 * Uploads the customer's payment receipt to Storage and records it in a create-only
 * `orderReceipts/{orderId}` document. The order document itself is never edited by the public.
 */
export async function submitPublicReceipt(
  storefront: PublishedStorefront,
  orderId: string,
  file: File,
  bankAccountId: string,
): Promise<{ receiptFileName: string; receiptUploadedAt: string }> {
  const { restaurantId, domain } = tenantOf(storefront);
  if (!/^ord-[a-f0-9]{32}$/.test(orderId)) throw new Error("This order cannot accept a receipt. Please contact the restaurant.");
  if (!(RECEIPT_ALLOWED_TYPES as readonly string[]).includes(file.type)) throw new Error("Only JPG, PNG, WEBP, or PDF files are accepted.");
  if (file.size > RECEIPT_MAX_BYTES) throw new Error("File must be under 10 MB.");

  const [{ ref, uploadBytes }, { storage }, { doc, setDoc, serverTimestamp, db }] = await Promise.all([
    import("firebase/storage"),
    import("./firebase"),
    fs(),
  ]);
  const path = receiptStoragePath(restaurantId, orderId);
  await uploadBytes(ref(storage, path), file, { contentType: file.type });
  const receiptUploadedAt = new Date().toISOString();
  await setDoc(doc(db, "restaurants", restaurantId, "orderReceipts", orderId), {
    orderId,
    restaurantId,
    domain,
    receiptPath: path,
    receiptFileName: file.name.slice(0, 200),
    bankAccountId,
    uploadedAt: receiptUploadedAt,
    submittedAt: serverTimestamp(),
  });
  return { receiptFileName: file.name, receiptUploadedAt };
}

// ── Reservations ──────────────────────────────────────────────────────────────

export type NewReservationInput = {
  name: string;
  email: string;
  phone: string;
  date: string;
  time: string;
  guests: number;
  notes?: string;
  paymentPaid?: boolean;
  paymentAmount?: number;
};

export async function submitPublicReservation(storefront: PublishedStorefront, input: NewReservationInput): Promise<string> {
  const { restaurantId, domain } = tenantOf(storefront);
  const { doc, setDoc, serverTimestamp, db } = await fs();
  const id = createSubmissionId("res");
  await setDoc(
    doc(db, "restaurants", restaurantId, "reservations", id),
    compact({
      id,
      restaurantId,
      domain,
      name: input.name,
      email: input.email,
      phone: input.phone,
      date: input.date,
      time: input.time,
      guests: input.guests,
      notes: input.notes,
      status: "pending",
      createdAt: new Date().toISOString(),
      // Only the outcome is stored — card details entered in the form are never sent anywhere.
      paymentPaid: input.paymentPaid ? true : undefined,
      paymentAmount: input.paymentPaid ? input.paymentAmount : undefined,
      submittedAt: serverTimestamp(),
    }),
  );
  return id;
}

// ── Contact messages ──────────────────────────────────────────────────────────

export type NewContactMessageInput = { name: string; email: string; subject: string; message: string };

export async function submitPublicContactMessage(storefront: PublishedStorefront, input: NewContactMessageInput): Promise<string> {
  const { restaurantId, domain } = tenantOf(storefront);
  const { doc, setDoc, serverTimestamp, db } = await fs();
  const id = createSubmissionId("msg");
  await setDoc(doc(db, "restaurants", restaurantId, "contactMessages", id), {
    id,
    restaurantId,
    domain,
    name: input.name,
    email: input.email,
    subject: input.subject,
    message: input.message,
    createdAt: new Date().toISOString(),
    submittedAt: serverTimestamp(),
  });
  return id;
}

// ── Review submissions (moderated; never written to published testimonials) ──

export type NewReviewInput = { name: string; text: string; rating: number };

export async function submitPublicReview(storefront: PublishedStorefront, input: NewReviewInput): Promise<string> {
  const { restaurantId, domain } = tenantOf(storefront);
  const { doc, setDoc, serverTimestamp, db } = await fs();
  const id = createSubmissionId("rev");
  await setDoc(doc(db, "restaurants", restaurantId, "reviewSubmissions", id), {
    id,
    restaurantId,
    domain,
    name: input.name,
    text: input.text,
    rating: Math.min(5, Math.max(1, Math.round(input.rating))),
    date: new Date().toISOString().slice(0, 10),
    status: "pending",
    submittedAt: serverTimestamp(),
  });
  return id;
}
