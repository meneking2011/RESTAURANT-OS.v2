import { collection, deleteField, doc, getDoc, getDocs, onSnapshot, setDoc, writeBatch } from "firebase/firestore";
import { auth, db } from "./firebase";
import { normalizeDomain } from "./publicStorefront";
import { buildPublishedProjection } from "./publishedProjection";
import { useRestaurantStore, getTenantSyncableState, getCleanTenantSeed, TENANT_DATA_FIELDS } from "@/store/restaurantStore";
import {
  CONTENT_COLLECTION_KEYS, CONTENT_MARKER_FIELD, contentCollectionPath, contentItems, fromContentDocs, markerFor,
  migratedKeys, planContentSync, sameSerialized, serializeContentDocs, stripInlineMedia, withoutContentCollections,
  type ContentCollectionKey,
} from "./tenantContent";
import { CUSTOMER_COLLECTION_KEYS, startCustomerDataSync, stopCustomerDataSync } from "./customerData";

let storeUnsubscribe: (() => void) | null = null;
let firestoreUnsubscribe: (() => void) | null = null;
let activeRestaurantId: string | null = null;
let activeOwnerUid: string | null = null;
let syncGeneration = 0;
let writeEpoch = 0;
let writeTimer: ReturnType<typeof setTimeout> | null = null;
/** C5: last known persisted (docId → serialized doc) per content subcollection, for minimal diff writes. */
let contentSynced: Partial<Record<ContentCollectionKey, Map<string, string>>> = {};
let contentUnsubscribers: (() => void)[] = [];
let pendingInit: { generation: number; resolve: () => void; reject: (error: Error) => void } | null = null;

/**
 * Suppress the next Zustand subscription callback (so hydrating the store
 * from a Firestore snapshot doesn't immediately echo back as a write).
 */
let suppressNextStoreWrite = false;

/**
 * Suppress the next onSnapshot hydration (so our own Firestore writes
 * don't echo back and overwrite any local state the admin just changed).
 */
let suppressNextHydration = false;
let suppressHydrationTimer: ReturnType<typeof setTimeout> | null = null;

// ─── Firestore sanitizer ─────────────────────────────────────────────────────
// Recursively strips `undefined` values — Firestore throws on any undefined field.

function sanitizeForFirestore(value: unknown): unknown {
  if (value === undefined) return null;
  if (value === null || typeof value !== "object") return value;
  if (Array.isArray(value)) {
    return value.map((item) => (item === undefined ? null : sanitizeForFirestore(item)));
  }
  const out: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(value as Record<string, unknown>)) {
    if (v !== undefined) out[k] = sanitizeForFirestore(v);
  }
  return out;
}

/**
 * Orders, reservations and the visit log are C3 customer records stored in per-restaurant
 * subcollections, not in the tenant document. They are never written by tenant sync.
 */
function withoutCustomerCollections(state: Record<string, unknown>): Record<string, unknown> {
  const out = { ...state };
  for (const key of CUSTOMER_COLLECTION_KEYS) delete out[key];
  return out;
}

/** Replace exactly the given top-level fields; legacy fields we do not manage are left untouched. */
const replaceFields = (data: Record<string, unknown>) => ({ mergeFields: Object.keys(data) });

function getSanitizedState(): Record<string, unknown> {
  const stripped: string[] = [];
  // C5: base64/data-URL images are never persisted. They must be uploaded through the media provider.
  const state = stripInlineMedia(
    withoutCustomerCollections(sanitizeForFirestore(getTenantSyncableState()) as Record<string, unknown>),
    (path) => stripped.push(path),
  );
  if (stripped.length) {
    console.warn(`[tenantSync] Inline image data was not saved (re-upload these images): ${stripped.join(", ")}`);
  }
  return state;
}

const BATCH_LIMIT = 400;

/**
 * C5: persist a logical tenant state. High-growth lists go to restaurants/{restaurantId}/{key}/{docId}
 * (only changed documents are written); the rest stays in the tenant document. Order matters for safe
 * migration: subcollections are committed first, then the tenant doc marks them as migrated and deletes
 * the legacy arrays in a single write. If any step fails, the legacy arrays are left untouched.
 */
async function persistTenantState(restaurantId: string, state: Record<string, unknown>, stillActive: () => boolean): Promise<void> {
  const ops: { key: ContentCollectionKey; op: ReturnType<typeof planContentSync>["ops"][number] }[] = [];
  const nextSynced: Partial<Record<ContentCollectionKey, Map<string, string>>> = {};
  for (const key of CONTENT_COLLECTION_KEYS) {
    let previous = contentSynced[key];
    if (!previous) {
      const existing = await getDocs(collection(db, ...contentCollectionPath(restaurantId, key)));
      previous = serializeContentDocs(existing.docs.map((d) => ({ id: d.id, data: d.data() as Record<string, unknown> })));
    }
    const plan = planContentSync(previous, contentItems(state, key));
    nextSynced[key] = plan.next;
    for (const op of plan.ops) ops.push({ key, op });
  }
  for (let i = 0; i < ops.length; i += BATCH_LIMIT) {
    if (!stillActive()) throw new Error("Tenant session changed during save.");
    const batch = writeBatch(db);
    for (const { key, op } of ops.slice(i, i + BATCH_LIMIT)) {
      const ref = doc(db, ...contentCollectionPath(restaurantId, key), op.id);
      if (op.type === "set") batch.set(ref, sanitizeForFirestore(op.data) as Record<string, unknown>);
      else batch.delete(ref);
    }
    await batch.commit();
  }
  if (!stillActive()) throw new Error("Tenant session changed during save.");
  const payload: Record<string, unknown> = {
    ...withoutContentCollections(state),
    [CONTENT_MARKER_FIELD]: markerFor(CONTENT_COLLECTION_KEYS),
  };
  for (const key of CONTENT_COLLECTION_KEYS) payload[key] = deleteField();
  await setDoc(doc(db, "restaurants", restaurantId), payload, replaceFields(payload));
  contentSynced = { ...contentSynced, ...nextSynced };
}


const TENANT_DOC_FIELDS = TENANT_DATA_FIELDS.filter((key) => !(CUSTOMER_COLLECTION_KEYS as readonly string[]).includes(key));

function isActiveTenantContext(restaurantId: string, generation: number, ownerUid: string): boolean {
  return (
    generation === syncGeneration &&
    activeRestaurantId === restaurantId &&
    activeOwnerUid === ownerUid &&
    Boolean(restaurantId) &&
    Boolean(ownerUid) &&
    auth.currentUser?.uid === ownerUid
  );
}

async function ownerStillOwnsRestaurant(ownerUid: string, restaurantId: string): Promise<boolean> {
  if (!ownerUid || !restaurantId) return false;
  if (auth.currentUser?.uid !== ownerUid) return false;
  try {
    const ownerSnap = await getDoc(doc(db, "owners", ownerUid));
    const assigned = ownerSnap.exists() ? ownerSnap.data()?.restaurantId : null;
    return typeof assigned === "string" && assigned === restaurantId;
  } catch (err) {
    console.error("[tenantSync] Owner verification failed:", err);
    return false;
  }
}

function armHydrationSuppression() {
  suppressNextHydration = true;
  if (suppressHydrationTimer) clearTimeout(suppressHydrationTimer);
  suppressHydrationTimer = setTimeout(() => {
    suppressNextHydration = false;
    suppressHydrationTimer = null;
  }, 6000);
}

function clearHydrationSuppression() {
  suppressNextHydration = false;
  if (suppressHydrationTimer) {
    clearTimeout(suppressHydrationTimer);
    suppressHydrationTimer = null;
  }
}

function abortPendingInit() {
  if (!pendingInit) return;
  const waiter = pendingInit;
  pendingInit = null;
  waiter.resolve();
}

// ─── Write helpers ───────────────────────────────────────────────────────────

function scheduleWrite(restaurantId: string, generation: number, ownerUid: string) {
  if (writeTimer) clearTimeout(writeTimer);
  const epoch = ++writeEpoch;
  writeTimer = setTimeout(() => {
    writeTimer = null;
    void flushTenantWrite(restaurantId, generation, ownerUid, epoch);
  }, 600);
}

async function flushTenantWrite(
  restaurantId: string,
  generation: number,
  ownerUid: string,
  epoch: number,
): Promise<boolean> {
  if (epoch !== writeEpoch) return false;
  if (!isActiveTenantContext(restaurantId, generation, ownerUid)) return false;
  const owns = await ownerStillOwnsRestaurant(ownerUid, restaurantId);
  if (epoch !== writeEpoch) return false;
  if (!owns || !isActiveTenantContext(restaurantId, generation, ownerUid)) return false;

  armHydrationSuppression();
  try {
    const state = getSanitizedState();
    await persistTenantState(restaurantId, state, () => isActiveTenantContext(restaurantId, generation, ownerUid));
    return true;
  } catch (err) {
    console.error("[tenantSync] Firestore write failed:", err);
    clearHydrationSuppression();
    return false;
  }
}

/**
 * Immediately flush the current store state to Firestore (no debounce).
 * Exported for the "Publish Changes" button.
 */
export async function publishCurrentTenant(): Promise<void> {
  const restaurantId = activeRestaurantId;
  const ownerUid = activeOwnerUid;
  const generation = syncGeneration;
  if (!restaurantId || !ownerUid) throw new Error("No authenticated restaurant is active.");
  if (!isActiveTenantContext(restaurantId, generation, ownerUid)) {
    throw new Error("Tenant session changed during publish.");
  }
  if (writeTimer) { clearTimeout(writeTimer); writeTimer = null; }
  writeEpoch += 1;

  const owns = await ownerStillOwnsRestaurant(ownerUid, restaurantId);
  if (!owns || !isActiveTenantContext(restaurantId, generation, ownerUid)) {
    throw new Error("Tenant session changed during publish.");
  }

  const state = getSanitizedState();
  const config = state.config as Record<string, unknown> | undefined;
  const customPages = Array.isArray(state.customPages) ? state.customPages : null;
  const navLinks = Array.isArray(state.navLinks) ? state.navLinks : null;
  if (!config || typeof config.name !== "string" || !customPages || !navLinks) {
    throw new Error("Publish blocked: required restaurant website data is incomplete.");
  }
  const validPageSlugs = new Set(customPages.map((page) => (page as { slug?: unknown }).slug).filter((slug): slug is string => typeof slug === "string"));
  const systemRoutes = new Set(["/", "/menu", "/about", "/services", "/reservations", "/locate-us", "/contact", "/checkout", "/gallery"]);
  const cleanedNavLinks = navLinks.filter((link) => {
    const href = (link as { href?: unknown }).href;
    return typeof href !== "string" || systemRoutes.has(href) || validPageSlugs.has(href);
  });
  if (!state.config || !state.siteTheme || !state.menuItems || !state.services || !state.testimonials || !state.galleryImages || !state.quickControls) {
    throw new Error("Publish blocked: public website data is incomplete.");
  }
  const validatedState: Record<string, unknown> = { ...state, navLinks: cleanedNavLinks };
  if (!isActiveTenantContext(restaurantId, generation, ownerUid)) throw new Error("Tenant session changed during publish.");
  const configuredDomain = typeof config.publicDomain === "string" ? normalizeDomain(config.publicDomain) : "";
  const platformHostname = "restaurant-os-88262.web.app";
  if (configuredDomain === platformHostname) {
    throw new Error("The RestaurantOS platform hostname cannot be used as a restaurant domain.");
  }
  const domainRef = configuredDomain ? doc(db, "domains", configuredDomain) : null;
  if (domainRef) {
    const existingDomain = await getDoc(domainRef);
    if (existingDomain.exists() && existingDomain.data().restaurantId !== restaurantId) {
      throw new Error("This public domain is already assigned to another restaurant.");
    }
  }
  if (!isActiveTenantContext(restaurantId, generation, ownerUid)) throw new Error("Tenant session changed during publish.");
  await persistTenantState(restaurantId, validatedState, () => isActiveTenantContext(restaurantId, generation, ownerUid));
  if (domainRef) {
    if (!isActiveTenantContext(restaurantId, generation, ownerUid)) throw new Error("Tenant session changed during publish.");
    await setDoc(domainRef, { restaurantId }, { merge: true });
  }

  // Explicit allow-listed projection (never a merge of the private document). setDoc without merge
  // replaces the whole published doc, so fields the owner disabled/removed cannot linger.
  // The projection builder filters bankAccounts: only entries with enabled === true are public.
  const publicProjection = buildPublishedProjection(restaurantId, validatedState);
  if (!isActiveTenantContext(restaurantId, generation, ownerUid)) throw new Error("Tenant session changed during publish.");
  await setDoc(doc(db, "published", restaurantId), publicProjection);
}

export async function forceSyncNow(): Promise<void> {
  const restaurantId = activeRestaurantId;
  const ownerUid = activeOwnerUid;
  const generation = syncGeneration;
  if (!restaurantId || !ownerUid) return;
  if (writeTimer) { clearTimeout(writeTimer); writeTimer = null; }
  await flushTenantWrite(restaurantId, generation, ownerUid, ++writeEpoch);
}

// ─── Main API ────────────────────────────────────────────────────────────────

/**
 * Starts a **real-time** Firestore listener on the restaurant document.
 *
 * - Initial snapshot: hydrates the store from Firestore (or seeds Firestore
 *   with default state on first launch).
 * - Subsequent snapshots: hydrate the store so any change made from another
 *   session (e.g. a customer placing an order) appears instantly without a
 *   page refresh.
 * - Local store mutations trigger a debounced write back to Firestore.
 * - Echo-back suppression flags prevent the two sides from looping.
 */
export async function startTenantSync(restaurantId: string, ownerUid: string): Promise<void> {
  if (!restaurantId || !ownerUid) {
    throw new Error("Tenant sync requires an authenticated owner and restaurantId");
  }

  stopTenantSync();
  const generation = ++syncGeneration;
  activeRestaurantId = restaurantId;
  activeOwnerUid = ownerUid;

  const owns = await ownerStillOwnsRestaurant(ownerUid, restaurantId);
  if (generation !== syncGeneration || activeRestaurantId !== restaurantId || activeOwnerUid !== ownerUid) {
    return;
  }
  if (!owns) {
    stopTenantSync();
    throw new Error("Tenant ownership could not be verified.");
  }

  const ref = doc(db, "restaurants", restaurantId);

  storeUnsubscribe = useRestaurantStore.subscribe((state, prev) => {
    if (!isActiveTenantContext(restaurantId, generation, ownerUid)) return;

    if (suppressNextStoreWrite) {
      // This change came from hydrateFromTenant — skip writing it back.
      suppressNextStoreWrite = false;
      return;
    }

    // Changes that only touch customer records (mirrored from their subcollections) are not tenant edits.
    const tenantFieldChanged = TENANT_DOC_FIELDS.some(
      (key) => (state as unknown as Record<string, unknown>)[key] !== (prev as unknown as Record<string, unknown>)[key],
    );
    if (!tenantFieldChanged) return;

    scheduleWrite(restaurantId, generation, ownerUid);
  });

  const active = () => generation === syncGeneration && activeRestaurantId === restaurantId && activeOwnerUid === ownerUid;
  contentSynced = {};
  let docCache: Record<string, unknown> | null = null;
  const subCache: Partial<Record<ContentCollectionKey, unknown[]>> = {};
  const subListening = new Set<ContentCollectionKey>();
  const subReady = new Set<ContentCollectionKey>();

  // Logical tenant state = tenant document + any migrated subcollection lists (legacy arrays are
  // still read from the document for tenants that have not been migrated yet).
  const composeState = (): Record<string, unknown> => {
    const out: Record<string, unknown> = { ...(docCache ?? {}) };
    for (const key of migratedKeys(docCache ?? {})) if (subCache[key] !== undefined) out[key] = subCache[key];
    return out;
  };
  const contentReady = () => !!docCache && migratedKeys(docCache).every((key) => subReady.has(key));
  const hydrateLogical = () => {
    if (!contentReady()) return;
    suppressNextStoreWrite = true;
    useRestaurantStore.getState().hydrateFromTenant(composeState() as never);
  };

  await new Promise<void>((resolve, reject) => {
    let settled = false;
    const timeout = setTimeout(() => {
      if (settled) return;
      settled = true;
      if (pendingInit?.generation === generation) pendingInit = null;
      if (generation === syncGeneration) {
        firestoreUnsubscribe?.();
        firestoreUnsubscribe = null;
      }
      reject(new Error("Firestore initialization timed out"));
    }, 10000);

    const finish = (error?: Error) => {
      if (settled) return;
      settled = true;
      clearTimeout(timeout);
      if (pendingInit?.generation === generation) pendingInit = null;
      if (error) reject(error);
      else resolve();
    };

    pendingInit = {
      generation,
      resolve: () => finish(),
      reject: (error) => finish(error),
    };

    // One listener per migrated content list, always under restaurants/{activeRestaurantId}/...
    const ensureContentListener = (key: ContentCollectionKey) => {
      if (subListening.has(key)) return;
      subListening.add(key);
      const unsub = onSnapshot(
        collection(db, ...contentCollectionPath(restaurantId, key)),
        (qs) => {
          if (!active()) return;
          const docs = qs.docs.map((d) => ({ id: d.id, data: d.data() as Record<string, unknown> }));
          const serialized = serializeContentDocs(docs);
          const isEcho = sameSerialized(serialized, contentSynced[key]);
          contentSynced[key] = serialized;
          subCache[key] = fromContentDocs(docs);
          const first = !subReady.has(key);
          subReady.add(key);
          // Our own writes echo back identical documents; only remote changes / first load hydrate.
          if (first || !isEcho) hydrateLogical();
          if (!settled && contentReady()) finish();
        },
        (err) => {
          console.error(`[tenantSync] ${key} listener error:`, err);
          if (!settled) finish(err);
        },
      );
      contentUnsubscribers.push(unsub);
    };

    firestoreUnsubscribe = onSnapshot(
      ref,
      (snap) => {
        if (!active()) return;
        if (snap.exists()) {
          docCache = snap.data() as Record<string, unknown>;
          migratedKeys(docCache).forEach(ensureContentListener);
          if (!suppressNextHydration) {
            // Remote change (or initial load) — replace the store from a clean
            // tenant snapshot so omitted fields cannot survive from a previous account.
            hydrateLogical();
          } else {
            // Echo-back from our own write — ignore and clear the flag.
            clearHydrationSuppression();
          }
        } else if (!settled) {
          // No document yet — first launch for this tenant.
          // Seed from clean defaults, never from the previous account's store.
          const seed = withoutCustomerCollections(sanitizeForFirestore(getCleanTenantSeed()) as Record<string, unknown>);
          suppressNextStoreWrite = true;
          useRestaurantStore.getState().hydrateFromTenant(seed as never);
          armHydrationSuppression();
          persistTenantState(restaurantId, seed, active).catch((err) => {
            console.error("[tenantSync] Initial seed failed:", err);
            if (generation === syncGeneration) clearHydrationSuppression();
          });
          finish();
          return;
        }

        if (!settled && contentReady()) finish();
      },
      (err) => {
        console.error("[tenantSync] Firestore listener error:", err);
        if (!settled) finish(err);
      }
    );
  }).catch((error) => {
    if (generation === syncGeneration) stopTenantSync();
    throw error;
  });

  if (generation !== syncGeneration || activeRestaurantId !== restaurantId || activeOwnerUid !== ownerUid) {
    return;
  }

  // Ownership is verified and the tenant is hydrated: mirror this owner's persisted customer records
  // (orders, reservations, receipts, messages, review submissions) into the admin session.
  startCustomerDataSync(restaurantId, ownerUid, () => isActiveTenantContext(restaurantId, generation, ownerUid));

  // C5 migration: tenants still holding legacy arrays in the tenant document are copied to their
  // subcollections on the next save (copy → mark → delete legacy, see persistTenantState).
  if (docCache && migratedKeys(docCache).length < CONTENT_COLLECTION_KEYS.length) {
    scheduleWrite(restaurantId, generation, ownerUid);
  }
}

export function stopTenantSync() {
  stopCustomerDataSync();
  contentUnsubscribers.forEach((unsub) => unsub());
  contentUnsubscribers = [];
  contentSynced = {};
  syncGeneration += 1;
  writeEpoch += 1;
  abortPendingInit();
  if (storeUnsubscribe)   { storeUnsubscribe();   storeUnsubscribe = null;   }
  if (firestoreUnsubscribe) { firestoreUnsubscribe(); firestoreUnsubscribe = null; }
  if (writeTimer)          { clearTimeout(writeTimer);          writeTimer = null;          }
  if (suppressHydrationTimer) { clearTimeout(suppressHydrationTimer); suppressHydrationTimer = null; }
  activeRestaurantId    = null;
  activeOwnerUid        = null;
  suppressNextStoreWrite = false;
  suppressNextHydration  = false;
}
