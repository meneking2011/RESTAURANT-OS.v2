import assert from "node:assert/strict";
import { readdirSync, readFileSync } from "node:fs";
import { join } from "node:path";
import { test } from "node:test";
import {
  createSubmissionId,
  receiptStoragePath,
  submitPublicContactMessage,
  submitPublicOrder,
  submitPublicReservation,
  submitPublicReview,
} from "./publicSubmissions.ts";
import type { PublishedStorefront } from "./publicStorefront.ts";

// Static + pure-logic C3 guards. No Firebase/zustand needed, so these run without installed deps.
const ROOT = join(import.meta.dirname, "..", "..");
const SRC = join(ROOT, "src");
const read = (rel: string) => readFileSync(join(SRC, rel), "utf8");
const rules = readFileSync(join(ROOT, "firestore.rules"), "utf8");
const storageRules = readFileSync(join(ROOT, "storage.rules"), "utf8");
const listTsx = (dir: string) => readdirSync(join(SRC, dir)).filter((f) => f.endsWith(".tsx")).map((f) => `${dir}/${f}`);

const PUBLIC_C3_FILES = ["pages/CheckoutPage.tsx", "pages/ReservationsPage.tsx", "pages/ContactPage.tsx", "components/sections/TestimonialsSection.tsx", "lib/publicSubmissions.ts"];

test("public C3 flows never use admin sync, the private store, owner auth, or a fallback tenant", () => {
  for (const file of PUBLIC_C3_FILES) {
    const code = read(file);
    assert.doesNotMatch(code, /startTenantSync|scheduleWrite|forceSyncNow|publishCurrentTenant|tenantSync/, file);
    assert.doesNotMatch(code, /store\/restaurantStore|customerData|customerInboxStore|lib\/auth/, file);
    assert.doesNotMatch(code, /getPublicRestaurantId|DEFAULT_RESTAURANT_ID|localStorage|hydrateFromTenant|resetTenantState/, file);
    assert.doesNotMatch(code, /["'`]default["'`]|rest_[A-Za-z0-9]/, file);
  }
});

test("public submission functions accept only the resolved storefront (no restaurantId parameter)", () => {
  const code = read("lib/publicSubmissions.ts");
  for (const fn of ["submitPublicOrder", "submitPublicReceipt", "submitPublicReservation", "submitPublicContactMessage", "submitPublicReview"]) {
    assert.match(code, new RegExp(`export async function ${fn}\\(\\s*storefront: PublishedStorefront`), fn);
  }
  assert.doesNotMatch(code, /restaurantId\s*[:=]\s*(input|data|params|args)\./);
});

test("checkout, reservations, contact and reviews all persist through the public submission module", () => {
  assert.match(read("pages/CheckoutPage.tsx"), /submitPublicOrder\(storefront/);
  assert.match(read("pages/CheckoutPage.tsx"), /submitPublicReceipt\(storefront/);
  assert.match(read("pages/ReservationsPage.tsx"), /submitPublicReservation\(storefront/);
  assert.match(read("pages/ContactPage.tsx"), /submitPublicContactMessage\(storefront/);
  assert.match(read("components/sections/TestimonialsSection.tsx"), /submitPublicReview\(storefront/);
});

test("card details entered in the reservation payment form are never persisted", () => {
  const code = read("pages/ReservationsPage.tsx");
  const call = code.slice(code.indexOf("submitPublicReservation(storefront"));
  const args = call.slice(0, call.indexOf("});"));
  assert.doesNotMatch(args, /cardNumber|cardName|cvv|expiry/);
});

test("public pages still never import the private store (C2 preserved)", () => {
  const files = [...listTsx("pages"), ...listTsx("components/layout"), ...listTsx("components/sections")];
  for (const file of files) assert.doesNotMatch(read(file), /store\/restaurantStore/, file);
});

test("submission ids are 128-bit hex and match the ids enforced by Firestore rules", () => {
  const a = createSubmissionId("ord");
  assert.match(a, /^ord-[a-f0-9]{32}$/);
  assert.notEqual(a, createSubmissionId("ord"));
  assert.match(createSubmissionId("res"), /^res-[a-f0-9]{32}$/);
  assert.match(createSubmissionId("msg"), /^msg-[a-f0-9]{32}$/);
  assert.match(createSubmissionId("rev"), /^rev-[a-f0-9]{32}$/);
  assert.equal(receiptStoragePath("rest_a", "ord-x"), "restaurants/rest_a/receipts/ord-x/receipt");
  for (const re of ["^ord-[a-f0-9]{32}$", "^res-[a-f0-9]{32}$", "^msg-[a-f0-9]{32}$", "^rev-[a-f0-9]{32}$"]) assert.ok(rules.includes(re), re);
});

test("a storefront that was not resolved from a domain mapping cannot submit anything", async () => {
  const unresolved = { restaurantId: "rest_a" } as PublishedStorefront; // no resolvedDomain
  const badId = { restaurantId: "someone-else", resolvedDomain: "a.example.com" } as PublishedStorefront;
  for (const storefront of [unresolved, badId]) {
    await assert.rejects(submitPublicOrder(storefront, {} as never), /could not be verified/);
    await assert.rejects(submitPublicReservation(storefront, {} as never), /could not be verified/);
    await assert.rejects(submitPublicContactMessage(storefront, {} as never), /could not be verified/);
    await assert.rejects(submitPublicReview(storefront, {} as never), /could not be verified/);
  }
});

// ── Firestore / Storage rules (static structure; full compilation needs the Firebase emulator) ──

function block(src: string, header: string): string {
  const start = src.indexOf(header);
  assert.ok(start >= 0, `missing ${header}`);
  let depth = 0;
  // The header itself may contain `{param}` segments; the body starts at the first `{` after it.
  for (let i = src.indexOf("{", start + header.length); i < src.length; i++) {
    if (src[i] === "{") depth++;
    if (src[i] === "}" && --depth === 0) return src.slice(start, i + 1);
  }
  throw new Error(`unbalanced ${header}`);
}

test("rules files have balanced braces/parens and every helper called is defined", () => {
  for (const text of [rules, storageRules]) {
    const noStrings = text.replace(/\/\/[^\n]*/g, "").replace(/'[^']*'/g, "''");
    assert.equal((noStrings.match(/\{/g) ?? []).length, (noStrings.match(/\}/g) ?? []).length);
    assert.equal((noStrings.match(/\(/g) ?? []).length, (noStrings.match(/\)/g) ?? []).length);
  }
  const defined = new Set([...rules.matchAll(/function (\w+)\(/g)].map((m) => m[1]));
  for (const name of ["isStr", "optStr", "isMoney", "tenantMatches", "storefrontAccepts", "publicOrderValid", "publicReceiptValid", "publicReservationValid", "publicContactValid", "publicReviewValid", "ownsRestaurant"]) {
    assert.ok(defined.has(name), `${name} not defined`);
  }
  const called = new Set([...rules.matchAll(/\b(public\w+Valid|tenantMatches|storefrontAccepts|isStr|optStr|isMoney|ownsRestaurant)\(/g)].map((m) => m[1]));
  for (const name of called) assert.ok(defined.has(name), `${name} called but not defined`);
});

test("no broad public rules; restaurants/{id} stays owner-only", () => {
  const openRules = [...rules.matchAll(/allow ([a-z, ]+):\s*if\s+true/g)].map((m) => m[1].trim());
  assert.deepEqual(openRules, ["read", "read"], "only domains/{domain} and published/{id} are publicly readable, and never writable");
  const restaurants = block(rules, "match /restaurants/{restaurantId}");
  assert.match(restaurants, /allow read: if ownsRestaurant\(restaurantId\);/);
  assert.doesNotMatch(rules, /match \/restaurants\/\{restaurantId\}\s*\{[^}]*allow read: if true/);
});

test("public visitors can only CREATE customer records; read/update/delete are owner-only", () => {
  const cases: Array<[string, string]> = [
    ["orders/{orderId}", "publicOrderValid"],
    ["orderReceipts/{orderId}", "publicReceiptValid"],
    ["reservations/{reservationId}", "publicReservationValid"],
    ["contactMessages/{messageId}", "publicContactValid"],
    ["reviewSubmissions/{reviewId}", "publicReviewValid"],
  ];
  for (const [path, validator] of cases) {
    const b = block(rules, `match /${path}`);
    const allows = [...b.matchAll(/allow ([a-z, ]+):\s*if ([^;]+);/g)];
    assert.ok(allows.length >= 2, path);
    for (const [, ops, cond] of allows) {
      if (ops.trim() === "create") assert.match(cond, new RegExp(`^${validator}\\(restaurantId, \\w+, request\\.resource\\.data\\)$`), path);
      else if (cond.trim() === "false") continue;
      else assert.match(cond, /ownsRestaurant\(restaurantId\)/, `${path}: '${ops}' must be owner-only`);
      assert.ok(!/\b(get|list|write)\b/.test(ops), `${path}: public read/write op`);
    }
  }
  // Owner updates are limited to specific fields (restaurantId / domain / ids are immutable).
  assert.match(block(rules, "match /orders/{orderId}"), /affectedKeys\(\)\.hasOnly\(\[\s*'status', 'paymentStatus'/);
  assert.match(block(rules, "match /orderReceipts/{orderId}"), /allow update: if false;/);
});

test("every public create rule binds the write to a published tenant whose domain maps to it", () => {
  const helper = block(rules, "function tenantMatches");
  assert.match(helper, /d\.restaurantId == restaurantId/);
  assert.match(helper, /exists\(\/databases\/\$\(database\)\/documents\/published\/\$\(restaurantId\)\)/);
  assert.match(helper, /documents\/domains\/\$\(d\.domain\)\)\.data\.restaurantId == restaurantId/);
  for (const fn of ["publicOrderValid", "publicReceiptValid", "publicReservationValid", "publicContactValid", "publicReviewValid"]) {
    const b = block(rules, `function ${fn}`);
    assert.match(b, /tenantMatches\(restaurantId, d\)/, fn);
    assert.match(b, /d\.submittedAt == request\.time/, fn);
    assert.match(b, /keys\(\)\.hasOnly\(/, fn);
  }
  assert.match(block(rules, "function publicOrderValid"), /d\.status == 'new'[\s\S]*d\.paymentStatus|d\.paymentStatus == 'pending_receipt'/);
  assert.match(block(rules, "function publicOrderValid"), /storefrontAccepts\(restaurantId, 'onlineOrders'\)/);
  assert.match(block(rules, "function publicReservationValid"), /storefrontAccepts\(restaurantId, 'acceptReservations'\)/);
});

test("published projection may carry only what checkout/reservations need; still owner-write only", () => {
  const published = block(rules, "match /published/{restaurantId}");
  for (const key of ["bankAccounts", "deliverySettings", "reservationSettings"]) assert.match(published, new RegExp(`'${key}'`));
  assert.match(published, /allow create, update: if ownsRestaurant\(restaurantId\)/);
  assert.doesNotMatch(published, /'orders'|'reservations'|'visitLog'|'activityLog'/);
});

test("storage: public may create exactly one receipt per awaiting order; nothing else", () => {
  const b = block(storageRules, "match /restaurants/{restaurantId}/receipts/{orderId}/{fileName}");
  assert.match(b, /allow read, delete: if ownsRestaurant\(restaurantId\);/);
  assert.match(b, /fileName == 'receipt'/);
  assert.match(b, /resource == null/);
  assert.match(b, /firestore\.exists\(.*orders\/\$\(orderId\)\)/);
  assert.match(b, /paymentStatus == 'pending_receipt'/);
  assert.match(b, /allow update: if false;/);
  assert.doesNotMatch(storageRules, /if true/);
});

test("tenant sync no longer writes customer collections and publishes checkout config", () => {
  const sync = read("lib/tenantSync.ts");
  assert.match(sync, /withoutCustomerCollections/);
  assert.match(sync, /mergeFields/);
  assert.match(sync, /bankAccounts:[\s\S]*enabled === true/);
  assert.match(sync, /startCustomerDataSync\(restaurantId, ownerUid/);
  assert.match(sync, /stopCustomerDataSync\(\);/);
  const data = read("lib/customerData.ts");
  assert.match(data, /"restaurants", restaurantId/);
  assert.doesNotMatch(data, /getPublicRestaurantId|DEFAULT_RESTAURANT_ID|"default"/);
});

test("only the admin tenant lifecycle imports customerData; App.tsx C2 structure intact", () => {
  const app = read("App.tsx");
  assert.doesNotMatch(app, /customerData|publicSubmissions/);
  assert.match(app, /function AuthScope[\s\S]*startsWith\("\/admin"\)\s*\?\s*<AuthProvider>/);
});
