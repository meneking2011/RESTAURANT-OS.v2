export default function PlatformHomepage({ error }: { error?: string | null }) {
  return (
    <main className="min-h-screen bg-background text-foreground">
      <section className="mx-auto flex min-h-screen w-full max-w-6xl flex-col justify-center px-6 py-20 sm:px-10">
        <div className="max-w-3xl space-y-8">
          <p className="text-sm font-medium uppercase tracking-[0.2em] text-muted-foreground">RestaurantOS</p>
          <h1 className="text-4xl font-semibold tracking-tight sm:text-6xl">The operating system for modern restaurants.</h1>
          <p className="max-w-2xl text-lg leading-8 text-muted-foreground">
            Manage your restaurant website, menus, reservations, orders, and customer experience from one place.
          </p>
          <div className="flex flex-wrap gap-3">
            <a className="rounded-md bg-primary px-5 py-3 text-sm font-medium text-primary-foreground transition-opacity hover:opacity-90" href="/admin/login">
              Sign in to your restaurant
            </a>
          </div>
        </div>
      </section>
    </main>
  );
}
